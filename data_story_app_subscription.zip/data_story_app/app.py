"""
data_story_app/app.py
======================

This module implements a lightweight data‑analysis and storytelling web
application using FastAPI and Jinja2.  The application allows users to
upload a CSV file, automatically profiles the uploaded dataset and
displays exploratory data analysis (EDA) results such as descriptive
statistics, a correlation heatmap and a simple narrative summarising
interesting findings.  A rudimentary chat interface is also provided
allowing users to ask basic questions about the data (e.g. "mean of
revenue" or "plot age vs salary").  Responses to these queries are
generated using simple pattern matching against the uploaded dataset.

The resulting application can be launched locally via

    uvicorn app:app --reload

Once running, navigate to `http://localhost:8000/` in your web browser
to interact with the interface.  The server keeps the uploaded dataset
and chat state in memory for the lifetime of the process (no
persistence layer is implemented), so this example is suitable for
demonstration purposes but not for production deployment.

Prerequisites:
    - Python 3.8+
    - fastapi
    - uvicorn
    - jinja2
    - pandas
    - plotly (for interactive charts)

All of these packages are installed in the provided container, but if
you're running this code outside the container you should install
them via pip.  A minimal requirements.txt is provided in the
repository root for convenience.
"""

from fastapi import FastAPI, Request, UploadFile, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.offline as po
from io import StringIO
import re
import os

# Import for type annotations used in helper functions
try:
    from sklearn.compose import ColumnTransformer  # type: ignore
except Exception:
    ColumnTransformer = None  # type: ignore

# Try to import optional LLM clients for natural language answers.
try:
    import openai  # type: ignore
except Exception:
    openai = None  # type: ignore
try:
    import anthropic  # type: ignore
except Exception:
    anthropic = None  # type: ignore

# Import get_plotlyjs to embed the script into the HTML so that
# charts work without an external network connection.  The returned
# string contains a minified copy of the Plotly JavaScript library.
from plotly.offline import get_plotlyjs


# Instantiate the FastAPI app
app = FastAPI(title="Data Story App")

# Set up Jinja2 templates; templates live in the `templates` directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

# Mount a static directory for serving assets (optional)
static_dir = os.path.join(BASE_DIR, "static")
if not os.path.exists(static_dir):
    os.makedirs(static_dir, exist_ok=True)
app.mount("/static", StaticFiles(directory=static_dir), name="static")

# In‑memory state for the currently loaded dataset and chat history.
# In a production system you'd implement proper per‑session storage or a
# database instead of these module‑level variables.
class AppState:
    dataset: pd.DataFrame | None = None
    preview_html: str | None = None
    summary_html: str | None = None
    corr_div: str | None = None
    narrative: str | None = None
    chat_history: list[dict] = []
    # Numeric columns detected in the currently loaded dataset. Used for target variable selection.
    numeric_columns: list[str] | None = None
    # Fields for storing predictive model outputs
    model_fig: str | None = None
    model_metrics: str | None = None
    model_importance: str | None = None

    # Additional exploratory analysis artefacts
    # Each list contains dicts with keys: 'title', 'figure', 'summary'
    hist_charts: list | None = None
    bar_charts: list | None = None
    time_series_charts: list | None = None
    box_charts: list | None = None

    # Scatter matrix charts for exploring pairwise relationships
    scatter_matrix_charts: list | None = None
    # Treemap charts for visualising category contributions to a numeric metric
    treemap_charts: list | None = None

    # Violin plots for numeric columns
    violin_charts: list | None = None
    # Pie charts for categorical variables
    pie_charts: list | None = None

    # Columns lists to populate UI selectors
    categorical_columns: list[str] | None = None
    datetime_columns: list[str] | None = None
    all_columns: list[str] | None = None

    # Storage for advanced predictive analytics results
    prediction_results: dict | None = None

    # Actionable insights HTML generated from EDA and predictive analytics
    actionable_insights_html: str | None = None
    # Suggested questions for the Ask Data interface
    question_suggestions: list[str] | None = None


state = AppState()

# Embed plotly.js into the template to avoid external network calls.
PLOTLY_JS = get_plotlyjs()


def load_dataset(file: UploadFile) -> pd.DataFrame:
    """Load a dataset from an uploaded file.

    Currently supports CSV files.  XLSX files could be added easily by
    checking file.content_type and using pandas.read_excel.

    Parameters
    ----------
    file : UploadFile
        The uploaded file object.

    Returns
    -------
    pd.DataFrame
        The loaded data.
    """
    # Read the file contents into a pandas DataFrame
    contents = file.file.read().decode("utf-8", errors="ignore")
    # Use StringIO to simulate a file handle for pandas
    data = pd.read_csv(StringIO(contents))
    return data


def generate_preview(df: pd.DataFrame, max_rows: int = 5) -> str:
    """Generate an HTML table preview of the first few rows."""
    preview_df = df.head(max_rows).copy()
    return preview_df.to_html(classes="dataframe table table-striped table-bordered", index=False, border=0)


def build_predictive_model(df: pd.DataFrame, target: str, top_n: int = 5):
    """Train a random forest model to predict the given target variable.

    This function automatically handles categorical and datetime columns using one‑hot encoding and
    extracting year/month/day components from datetimes. It returns a tuple containing:
    - an HTML div containing a Plotly bar chart of the top features,
    - an HTML string summarising model evaluation metrics,
    - an HTML table of the top feature importances.

    Parameters
    ----------
    df : pandas.DataFrame
        The dataset containing both features and target.
    target : str
        The name of the target variable to predict.
    top_n : int, default 5
        Number of top features to display.

    Returns
    -------
    tuple[str, str, str]
        fig_div, metrics_html, feature_importance_table_html
    """
    import numpy as np
    import pandas as pd
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import OneHotEncoder
    from sklearn.compose import ColumnTransformer
    from sklearn.pipeline import Pipeline
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    import plotly.express as px
    import plotly.offline as po

    # Create copies to avoid modifying original data
    data = df.copy()
    y = data.pop(target)
    X = data

    # Identify categorical, datetime, and numeric columns
    cat_cols = X.select_dtypes(include=['object']).columns.tolist()
    datetime_cols = X.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
    num_cols = X.select_dtypes(include=[np.number]).columns.tolist()

    # Extract date parts from datetime columns
    for col in datetime_cols:
        X[f"{col}_year"] = X[col].dt.year
        X[f"{col}_month"] = X[col].dt.month
        X[f"{col}_day"] = X[col].dt.day
    # Drop original datetime columns
    X.drop(columns=datetime_cols, inplace=True)
    # Update numeric feature list after expanding datetimes
    num_cols = [c for c in X.columns if c not in cat_cols]

    # Preprocess: one‑hot encode categorical variables, pass through numeric variables
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore'), cat_cols),
            ('num', 'passthrough', num_cols)
        ]
    )

    # Define model pipeline
    model = Pipeline([
        ('preprocessor', preprocessor),
        ('rf', RandomForestRegressor(n_estimators=200, random_state=42))
    ])

    # Train‑test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Fit model
    model.fit(X_train, y_train)

    # Predict and compute metrics
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    mse = mean_squared_error(y_test, preds)
    r2 = r2_score(y_test, preds)
    metrics_html = (
        f"<p><strong>Model Evaluation Metrics:</strong></p>"
        f"<ul>"
        f"<li>Mean Absolute Error (MAE): {mae:.2f}</li>"
        f"<li>Mean Squared Error (MSE): {mse:.2f}</li>"
        f"<li>R-squared (R²): {r2:.3f}</li>"
        f"</ul>"
    )

    # Extract feature names after preprocessing
    encoder = model.named_steps['preprocessor'].transformers_[0][1]
    encoded_cat_cols = encoder.get_feature_names_out(cat_cols)
    feature_names = list(encoded_cat_cols) + num_cols
    # Feature importances
    importances = model.named_steps['rf'].feature_importances_
    fi_df = pd.DataFrame({'Feature': feature_names, 'Importance': importances})
    fi_df.sort_values(by='Importance', ascending=False, inplace=True)
    top_features = fi_df.head(top_n)

    # Create Plotly bar chart for feature importances
    fig = px.bar(top_features.iloc[::-1], x='Importance', y='Feature', orientation='h',
                 title=f'Top {top_n} Feature Importances for predicting {target}')
    fig.update_layout(height=400, margin=dict(l=0, r=0, t=30, b=0))
    fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')

    # Convert top features to HTML table
    fi_table_html = top_features.to_html(classes='dataframe table table-striped table-bordered', index=False, border=0)

    return fig_div, metrics_html, fi_table_html


# ============================================================================
# Advanced predictive analytics
#
# The following helper functions implement an extensible framework for
# multi‑model predictive analytics supporting regression, classification and
# time series forecasting.  Users can choose the type of analysis, select
# target and feature columns, optionally enable simple feature engineering,
# and the system will train a set of candidate models with basic hyperparameter
# tuning.  It evaluates each model on a hold‑out set using appropriate
# metrics, selects the best model and returns a summary of the results along
# with diagnostic plots.  Feature importances or coefficients are also
# extracted where applicable.

def _prepare_features(
    df: pd.DataFrame,
    target: str,
    selected_features: list[str] | None,
    feature_engineering: bool,
    task: str,
) -> tuple[pd.DataFrame, pd.Series, list[str], ColumnTransformer]:
    """
    Prepare the feature matrix X and target vector y for classification or
    regression tasks.  This includes selecting the desired columns, handling
    datetime columns by extracting year/month/day, optionally adding simple
    polynomial terms (squared features) and building a ColumnTransformer to
    encode categorical variables.

    Parameters
    ----------
    df : pandas.DataFrame
        The full dataset.
    target : str
        The name of the target variable.
    selected_features : list[str] or None
        The feature columns selected by the user.  If None, use all
        columns except the target.
    feature_engineering : bool
        Whether to add squared terms for numeric features.
    task : str
        Either 'classification' or 'regression'.  Determines whether
        numeric or categorical targets are expected.

    Returns
    -------
    X : pandas.DataFrame
        The processed feature DataFrame.
    y : pandas.Series
        The target vector.
    feature_names : list[str]
        The list of processed feature names after encoding and feature
        engineering.  This will be used later for computing feature importances.
    preprocessor : ColumnTransformer
        The preprocessor used to handle categorical and numeric columns.
    """
    import numpy as np
    from sklearn.compose import ColumnTransformer
    from sklearn.preprocessing import OneHotEncoder

    # Copy to avoid mutating input
    data = df.copy()
    # Select features
    if selected_features:
        # Ensure selected features exist in dataframe
        features = [col for col in selected_features if col in data.columns and col != target]
    else:
        features = [col for col in data.columns if col != target]
    if not features:
        raise ValueError("No valid features selected for modelling.")
    # Separate X and y
    y = data[target].copy()
    X = data[features].copy()
    # Identify column types
    datetime_cols = X.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
    cat_cols = X.select_dtypes(include=['object', 'category']).columns.tolist()
    # All other columns are treated as numeric
    num_cols = [c for c in X.columns if c not in cat_cols + datetime_cols]
    # Extract date parts from datetime columns
    for col in datetime_cols:
        try:
            X[f"{col}_year"] = pd.to_datetime(X[col]).dt.year
            X[f"{col}_month"] = pd.to_datetime(X[col]).dt.month
            X[f"{col}_day"] = pd.to_datetime(X[col]).dt.day
        except Exception:
            # If conversion fails, drop the column
            continue
    # Drop original datetime columns from features
    X.drop(columns=datetime_cols, inplace=True)
    # Update numeric columns list after date part extraction
    num_cols = [c for c in X.columns if c not in cat_cols]
    # Feature engineering: add squared terms for numeric columns
    if feature_engineering:
        for col in num_cols:
            try:
                X[f"{col}_sq"] = X[col] ** 2
            except Exception:
                continue
    # Build the preprocessor: one‑hot encode categorical variables, passthrough numeric
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore'), cat_cols),
            ('num', 'passthrough', [c for c in X.columns if c not in cat_cols])
        ]
    )
    # Save the list of original numeric columns (for feature importances later)
    processed_num_cols = [c for c in X.columns if c not in cat_cols]
    # Combined feature names placeholder; actual feature names after encoding will be derived later
    feature_names: list[str] = []
    return X, y, processed_num_cols, preprocessor


def run_predictive_models(
    df: pd.DataFrame,
    analysis_type: str,
    target: str,
    selected_features: list[str] | None = None,
    date_col: str | None = None,
    feature_engineering: bool = False,
) -> dict:
    """
    Run multiple predictive models based on the specified analysis type and return
    a summary of results.  Supports regression, classification and time series
    forecasting.  For regression and classification tasks, the function
    automatically handles categorical and datetime features, performs simple
    hyperparameter tuning for each model, evaluates performance on a hold‑out
    test set and selects the best model.  For time series forecasting, it
    utilises ARIMA and machine learning models with lag features.

    Parameters
    ----------
    df : pandas.DataFrame
        The dataset to analyse.
    analysis_type : str
        One of 'regression', 'classification' or 'timeseries'.
    target : str
        The target variable to predict.
    selected_features : list[str], optional
        List of feature column names to use.  If None, all columns except
        the target are used.
    date_col : str, optional
        The column name representing dates for time series analysis.  If None
        and analysis_type is 'timeseries', the first datetime column is used.
    feature_engineering : bool, optional
        Whether to add squared numeric features for regression and classification.

    Returns
    -------
    dict
        A dictionary containing tables, plots and narrative summaries keyed as:
            - table_html: HTML table of model metrics
            - best_model_name: the name of the selected best model
            - best_model_plot: HTML div containing a Plotly chart for the best model
            - best_model_importance: HTML table of feature importances or coefficients (may be None)
            - best_model_summary: narrative summary of the results
            - confusion_matrix_plot: for classification, a heatmap of the confusion matrix (HTML div)
    """
    import numpy as np
    import pandas as pd
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import (
        mean_absolute_error,
        mean_squared_error,
        r2_score,
        accuracy_score,
        precision_score,
        recall_score,
        f1_score,
        confusion_matrix,
    )
    from sklearn.linear_model import LinearRegression, LogisticRegression
    from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
    from sklearn.neural_network import MLPRegressor, MLPClassifier
    # xgboost may not be installed in all environments; attempt import
    try:
        from xgboost import XGBRegressor, XGBClassifier  # type: ignore
    except Exception:
        XGBRegressor = None  # type: ignore
        XGBClassifier = None  # type: ignore
    from sklearn.compose import ColumnTransformer
    from sklearn.pipeline import Pipeline
    import plotly.express as px
    import plotly.offline as po
    # Statsmodels for ARIMA
    try:
        from statsmodels.tsa.arima.model import ARIMA  # type: ignore
    except Exception:
        ARIMA = None  # type: ignore

    results: dict = {
        "table_html": None,
        "best_model_name": None,
        "best_model_plot": None,
        "best_model_importance": None,
        "best_model_summary": None,
        "confusion_matrix_plot": None,
    }

    # Validate that target exists
    if target not in df.columns:
        raise ValueError(f"Target column '{target}' not found in dataset.")

    # Branch on analysis type
    analysis_type = analysis_type.lower()
    if analysis_type in {"regression", "classification"}:
        # Prepare features and target
        X, y, numeric_cols, preprocessor = _prepare_features(
            df, target, selected_features, feature_engineering, analysis_type
        )
        # For classification, ensure target is categorical
        is_classification = (analysis_type == "classification")
        if is_classification:
            # Convert target to categorical codes if numeric
            # If the target is numeric but classification is requested, bin into quartiles
            if pd.api.types.is_numeric_dtype(y):
                # Bin into 3 categories: low, medium, high
                try:
                    y_binned = pd.qcut(y.rank(method='first'), q=3, labels=False)
                    y = y_binned.astype(int)
                except Exception:
                    # Fallback: round values to nearest integer and treat as categorical
                    y = (y - y.min()) / (y.max() - y.min()) * 2
                    y = y.round().astype(int)
            else:
                # Encode string categories to integers for scikit‑learn models
                y = y.astype('category').cat.codes
        else:
            # For regression, ensure target is numeric
            if not pd.api.types.is_numeric_dtype(y):
                # Attempt to convert to numeric
                try:
                    y = pd.to_numeric(y, errors='coerce')
                except Exception:
                    raise ValueError("Target for regression must be numeric.")
        # Split into train/test sets
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y if is_classification else None
        )
        # Candidate models and parameter options
        model_specs = []
        if analysis_type == "regression":
            model_specs.append(("Linear Regression", LinearRegression(), [{}]))
            model_specs.append(("Random Forest", RandomForestRegressor(random_state=42), [
                {"n_estimators": 200, "max_depth": None},
                {"n_estimators": 300, "max_depth": 10}
            ]))
            # Use XGBRegressor if available
            if XGBRegressor is not None:
                model_specs.append(("XGBoost Regressor", XGBRegressor(objective='reg:squarederror', random_state=42, verbosity=0), [
                    {"n_estimators": 300, "max_depth": 5, "learning_rate": 0.1},
                    {"n_estimators": 200, "max_depth": 3, "learning_rate": 0.05}
                ]))
            # Add MLPRegressor as a lightweight deep learning model
            model_specs.append(("Neural Network Regressor", MLPRegressor(random_state=42, max_iter=100), [
                {"hidden_layer_sizes": (50,), "learning_rate_init": 0.001},
                {"hidden_layer_sizes": (100, 50), "learning_rate_init": 0.001}
            ]))
        else:  # classification
            model_specs.append(("Logistic Regression", LogisticRegression(max_iter=500, random_state=42), [
                {"C": 1.0},
                {"C": 0.1}
            ]))
            model_specs.append(("Random Forest Classifier", RandomForestClassifier(random_state=42), [
                {"n_estimators": 200, "max_depth": None},
                {"n_estimators": 300, "max_depth": 10}
            ]))
            if XGBClassifier is not None:
                model_specs.append(("XGBoost Classifier", XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42), [
                    {"n_estimators": 300, "max_depth": 5, "learning_rate": 0.1},
                    {"n_estimators": 200, "max_depth": 3, "learning_rate": 0.05}
                ]))
            model_specs.append(("Neural Network Classifier", MLPClassifier(max_iter=300, random_state=42), [
                {"hidden_layer_sizes": (50,), "learning_rate_init": 0.001},
                {"hidden_layer_sizes": (100, 50), "learning_rate_init": 0.001}
            ]))
        # Store metrics results for each model/param set
        metrics_results = []
        best_overall_score = -np.inf
        best_overall = None
        best_model_obj = None
        best_model_preprocessor = None
        best_importances = None
        best_y_test = None
        best_preds = None
        # Evaluate each model with each set of hyperparameters
        for model_name, base_model, param_list in model_specs:
            best_score_for_model = -np.inf
            best_param = None
            best_model_instance = None
            # Iterate parameter sets
            for params in param_list:
                try:
                    # Clone base model with parameters
                    model = base_model.__class__(**{**base_model.get_params(), **params})
                except Exception:
                    # Fallback if get_params fails
                    model = base_model
                # Build pipeline with preprocessor
                pipeline = Pipeline([
                    ('preprocessor', preprocessor),
                    ('model', model)
                ])
                # Fit pipeline
                try:
                    pipeline.fit(X_train, y_train)
                except Exception:
                    continue
                # Predict on test set
                try:
                    preds = pipeline.predict(X_test)
                except Exception:
                    continue
                # Compute evaluation metrics
                if analysis_type == "regression":
                    mae = mean_absolute_error(y_test, preds)
                    mse = mean_squared_error(y_test, preds)
                    r2 = r2_score(y_test, preds)
                    # Use R2 as primary score for selection
                    score = r2
                    metrics_results.append({
                        "Model": model_name,
                        "Parameters": str(params),
                        "MAE": mae,
                        "MSE": mse,
                        "R2": r2
                    })
                else:  # classification
                    acc = accuracy_score(y_test, preds)
                    precision = precision_score(y_test, preds, average='weighted', zero_division=0)
                    recall = recall_score(y_test, preds, average='weighted', zero_division=0)
                    f1 = f1_score(y_test, preds, average='weighted', zero_division=0)
                    # Use F1 as primary score for selection
                    score = f1
                    metrics_results.append({
                        "Model": model_name,
                        "Parameters": str(params),
                        "Accuracy": acc,
                        "Precision": precision,
                        "Recall": recall,
                        "F1": f1
                    })
                # Update best within this model
                if score > best_score_for_model:
                    best_score_for_model = score
                    best_param = params
                    best_model_instance = pipeline
                # Update global best
                if score > best_overall_score:
                    best_overall_score = score
                    best_overall = (model_name, params)
                    best_model_obj = pipeline
                    best_model_preprocessor = preprocessor
                    best_y_test = y_test
                    best_preds = preds
                    # Extract feature importances if available
                    try:
                        # After fitting, access the underlying model
                        # We need to get encoded feature names
                        # Preprocessor may transform categories; we need names
                        enc = pipeline.named_steps['preprocessor'].transformers_[0][1]
                        cat_cols = enc.get_feature_names_out() if hasattr(enc, 'get_feature_names_out') else []
                        # Numeric features (including engineered) come after categorical encodings
                        # We track numeric_cols (processed) and engineered features (num_cols + _sq)
                        trans_num_cols = [c for c in X_train.columns if c not in X_train.select_dtypes(include=['object', 'category']).columns.tolist()]
                        feature_names = list(cat_cols) + trans_num_cols
                        model_component = pipeline.named_steps['model']
                        if hasattr(model_component, 'feature_importances_'):
                            importances = model_component.feature_importances_
                            fi_df = pd.DataFrame({'Feature': feature_names, 'Importance': importances})
                            fi_df.sort_values(by='Importance', ascending=False, inplace=True)
                            best_importances = fi_df
                        elif hasattr(model_component, 'coef_'):
                            coef = model_component.coef_
                            # Coef may be multi‑dimensional in multiclass; take absolute mean
                            if coef.ndim > 1:
                                coef = np.mean(np.abs(coef), axis=0)
                            fi_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': coef})
                            fi_df['Importance'] = np.abs(fi_df['Coefficient'])
                            fi_df.sort_values(by='Importance', ascending=False, inplace=True)
                            best_importances = fi_df[['Feature', 'Importance']]
                        else:
                            best_importances = None
                    except Exception:
                        best_importances = None
        # Build metrics table
        try:
            metrics_df = pd.DataFrame(metrics_results)
            # Round numeric columns for readability
            for col in metrics_df.columns:
                if metrics_df[col].dtype.kind in 'f':
                    metrics_df[col] = metrics_df[col].round(3)
            table_html = metrics_df.to_html(classes='dataframe table table-striped table-bordered', index=False, border=0)
        except Exception:
            table_html = None
        # Prepare best model visualisation and narrative
        if best_model_obj is not None and best_y_test is not None and best_preds is not None:
            if analysis_type == "regression":
                # Scatter plot of predicted vs actual
                scatter_df = pd.DataFrame({"Actual": best_y_test, "Predicted": best_preds})
                fig = px.scatter(scatter_df, x="Actual", y="Predicted", trendline="ols", title="Predicted vs Actual")
                fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
                best_plot = po.plot(fig, include_plotlyjs=False, output_type='div')
                # Narrative summary
                narrative = (
                    f"The best performing model is <strong>{best_overall[0]}</strong> with parameters {best_overall[1]}. "
                    f"It achieved an R² of {best_overall_score:.3f}. The scatter plot above compares predicted vs actual values. "
                    f"Points close to the diagonal line indicate accurate predictions."
                )
            else:  # classification
                # Confusion matrix heatmap
                try:
                    cm = confusion_matrix(best_y_test, best_preds)
                    fig_cm = px.imshow(
                        cm,
                        text_auto=True,
                        labels=dict(x="Predicted", y="Actual", color="Count"),
                        title="Confusion Matrix"
                    )
                    fig_cm.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
                    cm_div = po.plot(fig_cm, include_plotlyjs=False, output_type='div')
                except Exception:
                    cm_div = None
                best_plot = cm_div
                narrative = (
                    f"The best performing model is <strong>{best_overall[0]}</strong> with parameters {best_overall[1]}. "
                    f"It achieved a weighted F1 score of {best_overall_score:.3f}. The confusion matrix above illustrates "
                    f"the model's classification performance across the observed classes."
                )
        else:
            best_plot = None
            narrative = None
        # Prepare feature importance table for best model
        if best_importances is not None:
            try:
                fi_top = best_importances.head(10).copy()
                fi_top = fi_top.rename(columns={fi_top.columns[1]: 'Importance'})
                fi_top_table = fi_top.to_html(classes='dataframe table table-striped table-bordered', index=False, border=0)
            except Exception:
                fi_top_table = None
        else:
            fi_top_table = None
        # Set results
        results["table_html"] = table_html
        results["best_model_name"] = best_overall[0] if best_overall else None
        results["best_model_plot"] = best_plot
        results["best_model_importance"] = fi_top_table
        results["best_model_summary"] = narrative
        results["confusion_matrix_plot"] = best_plot if analysis_type == "classification" else None
        return results

    elif analysis_type == "timeseries":
        # Ensure there is a datetime column
        # If date_col not provided, use first datetime column
        dt_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
        if not dt_cols and not date_col:
            raise ValueError("No datetime column available for time series analysis.")
        date_column = date_col if date_col in df.columns else (dt_cols[0] if dt_cols else None)
        if date_column is None:
            raise ValueError("Specified date column not found in dataset.")
        # Ensure target is numeric
        if not pd.api.types.is_numeric_dtype(df[target]):
            raise ValueError("For time series forecasting, the target must be numeric.")
        # Prepare time series
        ts_df = df[[date_column, target]].dropna().copy()
        ts_df[date_column] = pd.to_datetime(ts_df[date_column])
        ts_df.sort_values(by=date_column, inplace=True)
        ts_df.set_index(date_column, inplace=True)
        y = ts_df[target].astype(float)
        # Split into train and test (80/20) based on chronological order
        split_idx = int(len(y) * 0.8)
        y_train = y.iloc[:split_idx]
        y_test = y.iloc[split_idx:]
        # Optionally include exogenous features
        exog_features = None
        if selected_features:
            # Remove target and date column if present
            exog_cols = [c for c in selected_features if c in df.columns and c not in {target, date_column}]
            if exog_cols:
                exog_df = df[[date_column] + exog_cols].dropna().copy()
                exog_df[date_column] = pd.to_datetime(exog_df[date_column])
                exog_df.sort_values(by=date_column, inplace=True)
                exog_df.set_index(date_column, inplace=True)
                # Align with y index
                exog_df = exog_df.loc[y.index]
                exog_features = exog_df
        # Evaluate models
        model_metrics = []
        best_score = np.inf
        best_model_name_ts = None
        best_pred_series = None
        # 1. ARIMA
        if ARIMA is not None:
            for order in [(1, 1, 1), (2, 1, 2)]:
                try:
                    model = ARIMA(y_train, order=order)
                    model_fit = model.fit()
                    preds = model_fit.forecast(steps=len(y_test))
                    mae = mean_absolute_error(y_test, preds)
                    mse = mean_squared_error(y_test, preds)
                    model_metrics.append({"Model": f"ARIMA{order}", "MAE": mae, "MSE": mse})
                    if mse < best_score:
                        best_score = mse
                        best_model_name_ts = f"ARIMA{order}"
                        # Convert predictions to Pandas Series aligned with y_test index
                        best_pred_series = pd.Series(preds, index=y_test.index)
                except Exception:
                    continue
        # 2. Random Forest with lag features
        # Create supervised learning dataset with lags
        def create_lag_features(series: pd.Series, lags: int = 3) -> pd.DataFrame:
            df_lag = pd.DataFrame({f"lag_{i}": series.shift(i) for i in range(1, lags + 1)})
            df_lag["target"] = series
            return df_lag.dropna()
        try:
            lag_df = create_lag_features(y, lags=3)
            y_lag = lag_df["target"]
            X_lag = lag_df.drop(columns=["target"])
            # If exogenous features exist, join them on index
            if exog_features is not None:
                exog_lag = exog_features.loc[X_lag.index]
                X_lag = pd.concat([X_lag, exog_lag], axis=1)
            X_train_lag = X_lag.iloc[:split_idx - 3]
            y_train_lag = y_lag.iloc[:split_idx - 3]
            X_test_lag = X_lag.iloc[split_idx - 3:]
            y_test_lag = y_lag.iloc[split_idx - 3:]
            rf_ts = RandomForestRegressor(random_state=42, n_estimators=200)
            rf_ts.fit(X_train_lag, y_train_lag)
            preds_rf = rf_ts.predict(X_test_lag)
            mae_rf = mean_absolute_error(y_test_lag, preds_rf)
            mse_rf = mean_squared_error(y_test_lag, preds_rf)
            model_metrics.append({"Model": "Random Forest with lags", "MAE": mae_rf, "MSE": mse_rf})
            if mse_rf < best_score:
                best_score = mse_rf
                best_model_name_ts = "Random Forest with lags"
                best_pred_series = pd.Series(preds_rf, index=y_test_lag.index)
        except Exception:
            pass
        # 3. XGBoost with lag features (if available)
        if XGBRegressor is not None:
            try:
                lag_df = create_lag_features(y, lags=3)
                y_lag = lag_df["target"]
                X_lag = lag_df.drop(columns=["target"])
                if exog_features is not None:
                    exog_lag = exog_features.loc[X_lag.index]
                    X_lag = pd.concat([X_lag, exog_lag], axis=1)
                X_train_lag = X_lag.iloc[:split_idx - 3]
                y_train_lag = y_lag.iloc[:split_idx - 3]
                X_test_lag = X_lag.iloc[split_idx - 3:]
                y_test_lag = y_lag.iloc[split_idx - 3:]
                xgb_ts = XGBRegressor(objective='reg:squarederror', random_state=42, n_estimators=300, max_depth=5)
                xgb_ts.fit(X_train_lag, y_train_lag)
                preds_xgb = xgb_ts.predict(X_test_lag)
                mae_xgb = mean_absolute_error(y_test_lag, preds_xgb)
                mse_xgb = mean_squared_error(y_test_lag, preds_xgb)
                model_metrics.append({"Model": "XGBoost with lags", "MAE": mae_xgb, "MSE": mse_xgb})
                if mse_xgb < best_score:
                    best_score = mse_xgb
                    best_model_name_ts = "XGBoost with lags"
                    best_pred_series = pd.Series(preds_xgb, index=y_test_lag.index)
            except Exception:
                pass
        # 4. Naive forecast baseline: predict last observed value for all test points
        try:
            last_value = y_train.iloc[-1]
            preds_naive = pd.Series(last_value, index=y_test.index)
            mae_naive = mean_absolute_error(y_test, preds_naive)
            mse_naive = mean_squared_error(y_test, preds_naive)
            model_metrics.append({"Model": "Naive Forecast", "MAE": mae_naive, "MSE": mse_naive})
            if mse_naive < best_score:
                best_score = mse_naive
                best_model_name_ts = "Naive Forecast"
                best_pred_series = preds_naive
        except Exception:
            pass
        # Build table of metrics
        try:
            ts_metrics_df = pd.DataFrame(model_metrics)
            ts_metrics_df = ts_metrics_df.round(3)
            table_html = ts_metrics_df.to_html(classes='dataframe table table-striped table-bordered', index=False, border=0)
        except Exception:
            table_html = None
        # Plot actual vs predicted for best model
        best_plot = None
        narrative = None
        if best_pred_series is not None:
            try:
                plot_df = pd.DataFrame({"Actual": y_test, "Predicted": best_pred_series})
                fig = px.line(plot_df, title=f"Time Series Forecast: Actual vs Predicted ({best_model_name_ts})")
                fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
                best_plot = po.plot(fig, include_plotlyjs=False, output_type='div')
                narrative = (
                    f"Among the evaluated models, the <strong>{best_model_name_ts}</strong> achieved the lowest MSE of {best_score:.3f}. "
                    f"The line chart above compares the actual values of <strong>{target}</strong> with the forecasted values."
                )
            except Exception:
                best_plot = None
                narrative = None
        # Set results
        results["table_html"] = table_html
        results["best_model_name"] = best_model_name_ts
        results["best_model_plot"] = best_plot
        results["best_model_importance"] = None
        results["best_model_summary"] = narrative
        results["confusion_matrix_plot"] = None
        return results
    else:
        raise ValueError(f"Unsupported analysis type: {analysis_type}")


def generate_hist_charts(df: pd.DataFrame, max_cols: int = 3) -> list[dict]:
    """
    Generate histogram charts for up to `max_cols` numeric columns.

    Each entry in the returned list is a dictionary containing the chart title,
    the Plotly figure div (HTML) and a short textual summary highlighting
    descriptive statistics for the column.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of numeric columns to visualise. Defaults to 3.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.
    """
    charts: list[dict] = []
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not numeric_cols:
        return charts
    for col in numeric_cols[:max_cols]:
        try:
            fig = px.histogram(df, x=col, nbins=20, title=f"Distribution of {col}")
            fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            mean = df[col].mean()
            median = df[col].median()
            minimum = df[col].min()
            maximum = df[col].max()
            summary = (
                f"The distribution of <strong>{col}</strong> ranges from {minimum:.2f} to {maximum:.2f}. "
                f"The mean is {mean:.2f} and the median is {median:.2f}."
            )
            charts.append({"title": f"Distribution of {col}", "figure": fig_div, "summary": summary})
        except Exception:
            # Skip problematic columns silently
            continue
    return charts


def generate_bar_charts(df: pd.DataFrame, max_cols: int = 3, top_n: int = 10) -> list[dict]:
    """
    Generate bar charts for up to `max_cols` categorical columns showing the
    distribution of the most frequent categories.

    Each entry in the returned list is a dictionary containing the chart title,
    the Plotly figure div and a short summary describing the most common
    category.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of categorical columns to visualise. Defaults to 3.
    top_n : int, optional
        Number of top categories to display. Defaults to 10.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.
    """
    charts: list[dict] = []
    cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    if not cat_cols:
        return charts
    for col in cat_cols[:max_cols]:
        try:
            counts = df[col].value_counts().nlargest(top_n)
            # Create bar chart
            fig = px.bar(
                x=counts.index.astype(str),
                y=counts.values,
                title=f"Top {min(top_n, len(counts))} categories in {col}",
                labels={'x': col, 'y': 'Count'},
            )
            fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            top_cat = counts.index[0]
            top_count = counts.iloc[0]
            summary = f"The most common value in <strong>{col}</strong> is <strong>{top_cat}</strong> with {top_count} occurrences."
            charts.append({"title": f"{col} distribution", "figure": fig_div, "summary": summary})
        except Exception:
            continue
    return charts


def generate_time_series_charts(df: pd.DataFrame) -> list[dict]:
    """
    Generate line charts for time series analysis on the first datetime column
    and a few numeric columns.

    If a datetime column exists, we aggregate numeric columns by date and
    produce a line chart for the first numeric column.  A summary describing
    the overall trend is also generated.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.  If no datetime
        column is present, returns an empty list.
    """
    charts: list[dict] = []
    datetime_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not datetime_cols or not numeric_cols:
        return charts
    date_col = datetime_cols[0]
    metric_col = numeric_cols[0]
    try:
        # Ensure date column is a datetime index
        ts_df = df[[date_col, metric_col]].dropna().copy()
        ts_df[date_col] = pd.to_datetime(ts_df[date_col])
        ts_df.set_index(date_col, inplace=True)
        # Resample by day (D) if data spans multiple days, else by original frequency
        # Use sum for aggregation; users may modify as needed
        aggregated = ts_df.resample('D')[metric_col].sum().dropna()
        if aggregated.empty:
            return charts
        first_val = aggregated.iloc[0]
        last_val = aggregated.iloc[-1]
        change = ((last_val - first_val) / first_val) * 100 if first_val != 0 else 0
        direction = "increased" if change >= 0 else "decreased"
        summary = (
            f"From {aggregated.index.min().date()} to {aggregated.index.max().date()}, "
            f"the total <strong>{metric_col}</strong> {direction} by {abs(change):.2f}%. "
            f"It went from {first_val:.2f} to {last_val:.2f}."
        )
        # Create line chart
        fig = px.line(
            x=aggregated.index,
            y=aggregated.values,
            title=f"Trend of {metric_col} over time",
            labels={'x': date_col, 'y': metric_col}
        )
        fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        charts.append({
            "title": f"Trend of {metric_col} by date",
            "figure": fig_div,
            "summary": summary
        })
    except Exception:
        pass
    return charts


def generate_box_charts(df: pd.DataFrame, max_cols: int = 3) -> list[dict]:
    """
    Generate box plots for up to `max_cols` numeric columns.

    Box plots provide additional insight beyond histograms by showing the
    interquartile range, median and outliers.  For each selected numeric
    column this function builds a Plotly box chart and crafts a short
    summary describing the median, quartiles and range.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of numeric columns to visualise. Defaults to 3.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.
    """
    charts: list[dict] = []
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not numeric_cols:
        return charts
    # Only include up to max_cols numeric columns
    for col in numeric_cols[:max_cols]:
        try:
            # Create box plot
            fig = px.box(df, y=col, points='outliers', title=f"Box Plot of {col}")
            fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            # Compute statistics
            series = df[col].dropna()
            median = series.median()
            q1 = series.quantile(0.25)
            q3 = series.quantile(0.75)
            minimum = series.min()
            maximum = series.max()
            summary = (
                f"The box plot for <strong>{col}</strong> shows a median of {median:.2f}, "
                f"with the 25th percentile at {q1:.2f} and the 75th percentile at {q3:.2f}. "
                f"Values range from {minimum:.2f} to {maximum:.2f}."
            )
            charts.append({"title": f"Box Plot of {col}", "figure": fig_div, "summary": summary})
        except Exception:
            continue
    return charts


def generate_scatter_matrix_charts(df: pd.DataFrame, max_cols: int = 4) -> list[dict]:
    """
    Generate a scatter matrix (pairwise scatter plots) for up to `max_cols` numeric columns.

    A scatter matrix allows users to visually inspect relationships between multiple numeric
    variables simultaneously.  For each generated matrix, this function also computes
    pairwise correlations and highlights the strongest relationship in the summary.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of numeric columns to include in the scatter matrix. Defaults to 4.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.  If there are fewer than
        two numeric columns, returns an empty list.
    """
    charts: list[dict] = []
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if len(numeric_cols) < 2:
        return charts
    # Use only the first max_cols numeric columns
    cols = numeric_cols[:max_cols]
    try:
        # Compute correlation matrix for summary
        corr_matrix = df[cols].corr().abs()
        # Find the strongest off-diagonal correlation
        upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        max_corr = upper_tri.stack().sort_values(ascending=False)
        if not max_corr.empty:
            best_pair = max_corr.index[0]
            best_val = max_corr.iloc[0]
            summary = (
                f"The scatter matrix shows pairwise relationships among {len(cols)} variables. "
                f"The strongest correlation is between <strong>{best_pair[0]}</strong> and "
                f"<strong>{best_pair[1]}</strong> with a correlation of {best_val:.2f}."
            )
        else:
            summary = "The scatter matrix shows weak correlations among the selected variables."
        fig = px.scatter_matrix(df[cols], dimensions=cols, title="Scatter Matrix for Selected Numeric Columns")
        fig.update_layout(height=600, width=600, margin=dict(l=0, r=0, t=40, b=0))
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        charts.append({"title": "Scatter Matrix", "figure": fig_div, "summary": summary})
    except Exception:
        pass
    return charts


def generate_treemap_charts(df: pd.DataFrame, max_cats: int = 1, agg_func: str = 'sum') -> list[dict]:
    """
    Generate treemap charts to visualise how categorical groups contribute to a numeric metric.

    This function selects the first categorical column and up to the first numeric column,
    aggregates the numeric metric by category using the specified aggregation function, and
    builds a treemap.  A short summary highlights the dominant category and its share.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cats : int, optional
        Maximum number of categorical columns to consider. Defaults to 1.
    agg_func : str, optional
        Aggregation function to apply to the numeric metric (e.g. 'sum' or 'mean'). Defaults to 'sum'.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.  Returns empty list if
        no suitable categorical or numeric columns are found.
    """
    charts: list[dict] = []
    # Identify categorical and numeric columns
    cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not cat_cols or not num_cols:
        return charts
    # Use only the first categorical and first numeric column for simplicity
    cat_col = cat_cols[0]
    num_col = num_cols[0]
    try:
        # Aggregate the numeric column by category
        if agg_func == 'mean':
            agg_series = df.groupby(cat_col)[num_col].mean()
            agg_name = f"average {num_col}"
        else:
            agg_series = df.groupby(cat_col)[num_col].sum()
            agg_name = f"total {num_col}"
        # Sort descending
        agg_series = agg_series.sort_values(ascending=False)
        # Compute share for summary
        total_val = agg_series.sum()
        if total_val > 0:
            top_cat = agg_series.index[0]
            top_val = agg_series.iloc[0]
            share = (top_val / total_val) * 100
            summary = (
                f"The treemap visualises {agg_name} by {cat_col}. "
                f"<strong>{top_cat}</strong> accounts for {share:.1f}% of the overall {agg_name}."
            )
        else:
            summary = f"All categories have zero {agg_name}."
        # Create a DataFrame for Plotly treemap
        treemap_df = pd.DataFrame({cat_col: agg_series.index.astype(str), agg_name: agg_series.values})
        # Build treemap using path parameter for stability across Plotly versions
        fig = px.treemap(
            treemap_df,
            path=[cat_col],
            values=agg_name,
            title=f"Treemap of {agg_name} by {cat_col}",
            labels={cat_col: cat_col, agg_name: agg_name}
        )
        # Remove color scale (use default discrete color)
        fig.update_traces(marker=dict(colorscale='Blues'))
        fig.update_layout(height=500, margin=dict(l=0, r=0, t=40, b=0))
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        charts.append({"title": f"Treemap of {agg_name} by {cat_col}", "figure": fig_div, "summary": summary})
    except Exception:
        # If anything fails, do not add a chart but return empty list
        return charts
    return charts


def generate_actionable_insights(df: pd.DataFrame, prediction_results: dict | None = None) -> tuple[str, list[str]]:
    """
    Derive actionable insights from the EDA and predictive analytics results.

    This function analyses the uploaded dataset to identify key correlations,
    dominant categories, and influential features from the predictive models. It
    constructs a set of recommended actions that users can take based on these
    findings and also returns a list of suggested questions to prompt
    exploration in the Ask Data interface.

    Parameters
    ----------
    df : pandas.DataFrame
        The uploaded dataset.
    prediction_results : dict, optional
        Results returned from the predictive analytics.  If provided, the
        function attempts to extract the top feature names from the
        ``best_model_importance`` table for inclusion in the insights.

    Returns
    -------
    tuple[str, list[str]]
        A tuple containing an HTML string of actionable insights and a list of
        suggested questions.  If insufficient information is available, both
        elements may be empty.
    """
    insights: list[str] = []
    suggestions: list[str] = []
    # 1. Correlation analysis for numeric variables
    numeric_df = df.select_dtypes(include=[np.number])
    if not numeric_df.empty:
        try:
            corr = numeric_df.corr().abs()
            # Exclude self correlations by setting diagonal to NaN
            np.fill_diagonal(corr.values, np.nan)
            # Find index of max correlation
            max_pair = corr.unstack().idxmax()
            max_val = corr.loc[max_pair]
            if pd.notnull(max_val) and max_val > 0.3:
                col1, col2 = max_pair
                direction = "positive" if numeric_df[col1].corr(numeric_df[col2]) > 0 else "negative"
                insights.append(
                    f"<strong>{col1}</strong> and <strong>{col2}</strong> show a {direction} correlation of {max_val:.2f}. "
                    f"Consider investigating whether changes in <strong>{col1}</strong> drive variations in <strong>{col2}</strong>."
                )
                suggestions.append(f"How does {col1} affect {col2}?")
        except Exception:
            pass
    # 2. Category contribution using the first categorical and numeric columns
    cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    num_cols = numeric_df.columns.tolist()
    if cat_cols and num_cols:
        cat_col = cat_cols[0]
        num_col = num_cols[0]
        try:
            agg_series = df.groupby(cat_col)[num_col].sum().sort_values(ascending=False)
            total_val = agg_series.sum()
            if total_val > 0:
                top_cat = agg_series.index[0]
                top_val = agg_series.iloc[0]
                share = (top_val / total_val) * 100
                insights.append(
                    f"The category <strong>{top_cat}</strong> accounts for {share:.1f}% of total {num_col}. "
                    f"Focus on this category to maximise returns or replicate its success in other areas."
                )
                suggestions.append(f"Which categories contribute most to {num_col}?")
        except Exception:
            pass
    # 3. Top features from predictive analytics
    if prediction_results and prediction_results.get('best_model_importance'):
        try:
            # Extract table from HTML into DataFrame
            fi_table_html = prediction_results['best_model_importance']
            fi_df_list = pd.read_html(fi_table_html)
            if fi_df_list:
                fi_df = fi_df_list[0]
                # Assume the first column is "Feature"
                top_features = fi_df.iloc[:3]['Feature'].tolist()
                if top_features:
                    insights.append(
                        "Top predictive drivers include " + ", ".join(f"<strong>{feat}</strong>" for feat in top_features) + ". "
                        "Prioritise these variables in your strategies to improve performance."
                    )
                    suggestions.append(f"Which features are most important in predicting {prediction_results.get('best_model_name', 'the target')}?")
        except Exception:
            pass
    # 4. Generic suggestions if dataset has time series
    datetime_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
    if datetime_cols and num_cols:
        suggestions.append(f"What is the trend of {num_cols[0]} over time?")
        suggestions.append(f"Compare the last two periods of {num_cols[0]}")
    # Generate default narrative if no insights found
    if not insights:
        insights.append("Explore correlations, dominant categories and feature importances to uncover actionable insights from your data.")
    # Remove duplicates
    suggestions = list(dict.fromkeys(suggestions))
    # Format as HTML list
    html = "<ul>" + "".join(f"<li>{item}</li>" for item in insights) + "</ul>"
    return html, suggestions


def generate_violin_charts(df: pd.DataFrame, max_cols: int = 3) -> list[dict]:
    """
    Generate violin plots for up to ``max_cols`` numeric columns.

    Violin plots combine a boxplot and kernel density estimate to show the
    distribution shape and variability. Each entry in the returned list
    contains the chart title, Plotly figure div and a short summary
    highlighting the median and interquartile range.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of numeric columns to visualise. Defaults to 3.

    Returns
    -------
    list of dict
        Each dict has keys ``title``, ``figure`` and ``summary``.
    """
    charts: list[dict] = []
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not numeric_cols:
        return charts
    for col in numeric_cols[:max_cols]:
        try:
            fig = px.violin(df, y=col, box=True, points="outliers", title=f"Violin Plot of {col}")
            fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            series = df[col].dropna()
            median = series.median()
            q1 = series.quantile(0.25)
            q3 = series.quantile(0.75)
            summary = (
                f"The violin plot for <strong>{col}</strong> shows a median of {median:.2f}. "
                f"The interquartile range spans from {q1:.2f} to {q3:.2f}, illustrating the spread of the middle 50% of values."
            )
            charts.append({"title": f"Violin Plot of {col}", "figure": fig_div, "summary": summary})
        except Exception:
            continue
    return charts


def generate_pie_charts(df: pd.DataFrame, max_cols: int = 1, top_n: int = 10) -> list[dict]:
    """
    Generate pie charts for the first few categorical columns.

    Pie charts illustrate the composition of categories within a column. For each
    selected column, the distribution of the top ``top_n`` categories is
    visualised. A summary identifies the largest category and its percentage share.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of categorical columns to visualise. Defaults to 1.
    top_n : int, optional
        Number of top categories to display. Defaults to 10.

    Returns
    -------
    list of dict
        Each dict has keys ``title``, ``figure`` and ``summary``.
    """
    charts: list[dict] = []
    cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    if not cat_cols:
        return charts
    for col in cat_cols[:max_cols]:
        try:
            counts = df[col].value_counts().nlargest(top_n)
            # Compute share
            total = counts.sum()
            if total == 0:
                continue
            top_cat = counts.index[0]
            top_val = counts.iloc[0]
            share = (top_val / total) * 100
            summary = (
                f"The pie chart for <strong>{col}</strong> shows that the most common category is <strong>{top_cat}</strong>, "
                f"representing {share:.1f}% of the top {len(counts)} categories."
            )
            # Use a donut chart (pie chart with a hole) and display both actual values and percentages on the segments
            fig = px.pie(
                names=counts.index.astype(str),
                values=counts.values,
                title=f"Top {len(counts)} categories in {col}",
                hole=0.4
            )
            # Configure text to show label, value and percentage
            fig.update_traces(textposition='inside', textinfo='label+value+percent')
            fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            charts.append({"title": f"Donut Chart of {col}", "figure": fig_div, "summary": summary})
        except Exception:
            continue
    return charts


def generate_summary(df: pd.DataFrame) -> str:
    """Compute descriptive statistics for numeric columns and render as HTML."""
    # Only include numeric columns for summary statistics
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.empty:
        return "<p>No numeric columns available for summary statistics.</p>"
    desc = numeric_df.describe().transpose()
    desc.reset_index(inplace=True)
    desc.rename(columns={"index": "column"}, inplace=True)
    # Round statistics for readability
    desc = desc.round(3)
    return desc.to_html(classes="dataframe table table-striped table-bordered", index=False, border=0)


def generate_correlation_heatmap(df: pd.DataFrame) -> str:
    """Create a Plotly correlation heatmap and return HTML div."""
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.shape[1] < 2:
        return ""
    corr_matrix = numeric_df.corr()
    fig = px.imshow(
        corr_matrix,
        text_auto=False,
        aspect="auto",
        labels=dict(color="Correlation"),
        x=corr_matrix.columns,
        y=corr_matrix.index,
        title="Correlation Heatmap"
    )
    fig.update_layout(height=500)
    # Convert Plotly figure to an HTML div string.  We exclude the
    # Plotly.js library here to avoid multiple inclusions on the page; the
    # script is included once in the base template.
    heatmap_div = po.plot(fig, include_plotlyjs=False, output_type='div')
    return heatmap_div


def generate_narrative(df: pd.DataFrame) -> str:
    """Generate a simple textual narrative summarising the dataset.

    This heuristic narrative calls out interesting aspects of the data:
    the number of rows/columns, the column with the most missing values,
    columns with the largest mean values, and highly correlated pairs.

    Returns an HTML string.
    """
    n_rows, n_cols = df.shape
    numeric_df = df.select_dtypes(include=[np.number])
    narrative_parts = []

    # Data size
    narrative_parts.append(
        f"<p>Your dataset contains <strong>{n_rows}</strong> rows and <strong>{n_cols}</strong> columns.</p>"
    )

    # Missing values
    missing_counts = df.isna().sum()
    if missing_counts.sum() > 0:
        max_missing_col = missing_counts.idxmax()
        max_missing_count = missing_counts[max_missing_col]
        narrative_parts.append(
            f"<p>The column with the most missing values is <strong>{max_missing_col}</strong> "
            f"with <strong>{int(max_missing_count)}</strong> missing entries.</p>"
        )
    else:
        narrative_parts.append("<p>There are no missing values in this dataset.</p>")

    # Largest mean values
    if not numeric_df.empty:
        means = numeric_df.mean().sort_values(ascending=False)
        top_means = means.head(min(3, len(means)))
        top_mean_phrases = [f"<strong>{col}</strong> (mean={val:.2f})" for col, val in top_means.items()]
        narrative_parts.append(
            "<p>The columns with the highest mean values are: " + ", ".join(top_mean_phrases) + ".</p>"
        )

        # Highly correlated pairs
        corr_matrix = numeric_df.corr().abs()
        # Select upper triangle of correlation matrix to avoid duplicates and self correlations
        upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        # Identify pairs above threshold
        threshold = 0.8
        high_corr = [(col1, col2, val) for col1 in upper_tri.columns for col2, val in upper_tri[col1].dropna().items() if val >= threshold]
        if high_corr:
            phrases = [f"<strong>{c1}</strong> and <strong>{c2}</strong> (corr={val:.2f})" for c1, c2, val in high_corr]
            narrative_parts.append(
                "<p>Highly correlated column pairs include: " + "; ".join(phrases) + ".</p>"
            )

    return "\n".join(narrative_parts)


def handle_query(df: pd.DataFrame, query: str) -> tuple[str, str | None]:
    """Interpret a simple natural language query and return a response.

    The function looks for patterns such as 'mean of column', 'median of column',
    'sum of column', 'max of column', 'min of column', 'plot col1 vs col2',
    'plot distribution of column', 'correlation between col1 and col2', and
    'count' (number of rows).

    It returns a tuple consisting of the textual answer and an optional
    Plotly figure represented as an HTML div string.  If the query could
    not be parsed, a message is returned along with None.

    Parameters
    ----------
    df : pd.DataFrame
        The dataset to query.
    query : str
        The user's freeform question.

    Returns
    -------
    Tuple[str, Optional[str]]
        A textual answer and optionally an HTML div for a chart.
    """
    # Lowercase the query for easier matching
    q = query.strip().lower()

    # Actionable insights: if user asks about recommended actions or insights
    if any(keyword in q for keyword in ["action", "actions", "insight", "insights"]):
        """
        When the query asks for actions or insights, return the actionable insights
        generated during analysis. If not yet computed, derive them on the fly.
        """
        try:
            # If actionable insights haven't been computed or are empty, compute them
            if not state.actionable_insights_html:
                insights_html, suggestions = generate_actionable_insights(df, state.prediction_results)
                state.actionable_insights_html = insights_html
                state.question_suggestions = suggestions
            # Strip HTML tags for chat response
            import re as _re
            plain = _re.sub('<[^<]+?>', '', state.actionable_insights_html)
            return ("Here are some recommended actions based on the analysis:\n" + plain, None)
        except Exception:
            return ("Actionable insights are not available yet. Please run the analysis first.", None)

    # Handle count
    if re.fullmatch(r"(number of rows|count)", q):
        return (f"The dataset contains {df.shape[0]} rows.", None)

    # Mean
    m = re.match(r"mean of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The mean of {col} is {df[col].mean():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Median
    m = re.match(r"median of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The median of {col} is {df[col].median():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Sum
    m = re.match(r"sum of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The sum of {col} is {df[col].sum():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Max
    m = re.match(r"max(?:imum)? of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The maximum of {col} is {df[col].max():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Min
    m = re.match(r"min(?:imum)? of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The minimum of {col} is {df[col].min():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Correlation between columns
    m = re.match(r"corr(?:elation)? between ([\w\s]+) and ([\w\s]+)", q)
    if m:
        col1 = m.group(1).strip()
        col2 = m.group(2).strip()
        if (col1 in df.columns and col2 in df.columns and 
                pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2])):
            corr_val = df[col1].corr(df[col2])
            return (f"The correlation between {col1} and {col2} is {corr_val:.3f}.", None)
        else:
            return (f"One or both columns not found or not numeric.", None)

    # Histogram / distribution
    m = re.match(r"(plot|show) (?:the )?(?:distribution|histogram) of ([\w\s]+)", q)
    if m:
        col = m.group(2).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            fig = px.histogram(df, x=col, nbins=20, title=f"Distribution of {col}")
            fig.update_layout(height=400)
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            return (f"Here is the distribution of {col}.", fig_div)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Scatter plot
    m = re.match(r"(plot|show) ([\w\s]+) vs ([\w\s]+)", q)
    if m:
        col1 = m.group(2).strip()
        col2 = m.group(3).strip()
        if (col1 in df.columns and col2 in df.columns and 
                pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2])):
            fig = px.scatter(df, x=col1, y=col2, title=f"{col1} vs {col2}")
            fig.update_layout(height=400)
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            return (f"Here is the scatter plot of {col1} vs {col2}.", fig_div)
        else:
            return (f"One or both columns not found or not numeric.", None)

    # Trend analysis query: plot the trend of a numeric column over the first datetime column
    m = re.match(r"(?:trend(?: of)?|plot trend of|show trend of) ([\w\s]+)", q)
    if m:
        target_col = m.group(1).strip()
        # Identify date column
        datetime_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
        if not datetime_cols:
            return ("No datetime column found for trend analysis.", None)
        if target_col not in df.columns or not pd.api.types.is_numeric_dtype(df[target_col]):
            return (f"Column '{target_col}' not found or is not numeric.", None)
        date_col = datetime_cols[0]
        ts_df = df[[date_col, target_col]].dropna().copy()
        ts_df[date_col] = pd.to_datetime(ts_df[date_col])
        ts_df.set_index(date_col, inplace=True)
        aggregated = ts_df.resample('D')[target_col].sum().dropna()
        if aggregated.empty:
            return ("Not enough data to compute trend.", None)
        first_val = aggregated.iloc[0]
        last_val = aggregated.iloc[-1]
        change = ((last_val - first_val) / first_val) * 100 if first_val != 0 else 0
        direction = "increased" if change >= 0 else "decreased"
        summary = (
            f"From {aggregated.index.min().date()} to {aggregated.index.max().date()}, the total {target_col} {direction} by {abs(change):.2f}% "
            f"(from {first_val:.2f} to {last_val:.2f})."
        )
        fig = px.line(x=aggregated.index, y=aggregated.values, title=f"Trend of {target_col} over time", labels={'x': date_col, 'y': target_col})
        fig.update_layout(height=400)
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        return (summary, fig_div)

    # Period comparison query: compare the last two periods (months) of a numeric column
    m = re.match(r"(?:period comparison|compare periods|period change) ([\w\s]+)", q)
    if m:
        target_col = m.group(1).strip()
        # Identify date column
        datetime_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
        if not datetime_cols:
            return ("No datetime column found for period comparison.", None)
        if target_col not in df.columns or not pd.api.types.is_numeric_dtype(df[target_col]):
            return (f"Column '{target_col}' not found or is not numeric.", None)
        date_col = datetime_cols[0]
        temp_df = df[[date_col, target_col]].dropna().copy()
        temp_df[date_col] = pd.to_datetime(temp_df[date_col])
        temp_df.set_index(date_col, inplace=True)
        # Aggregate monthly sums
        monthly = temp_df.resample('M')[target_col].sum().dropna()
        if len(monthly) < 2:
            return ("Not enough data for period comparison.", None)
        last_two = monthly.tail(2)
        period_names = [d.strftime('%Y-%m') for d in last_two.index]
        values = last_two.values
        difference = values[-1] - values[-2]
        pct_change = ((values[-1] - values[-2]) / values[-2]) * 100 if values[-2] != 0 else 0
        direction = "higher" if values[-1] >= values[-2] else "lower"
        summary = (
            f"In {period_names[1]}, {target_col} was {values[-1]:.2f}, which is {direction} than {period_names[0]} by {abs(difference):.2f} "
            f"({abs(pct_change):.2f}% change)."
        )
        # Bar chart showing the two periods
        fig = px.bar(x=period_names, y=values, title=f"{target_col} comparison of last two months", labels={'x': 'Period', 'y': target_col})
        fig.update_layout(height=400)
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        return (summary, fig_div)

    # Fallback
    # If the query is not recognised by our patterns, attempt to call an LLM API
    llm_answer = call_llm(query, df)
    if llm_answer is not None:
        return (llm_answer, None)
    # Default fallback message
    return ("I'm sorry, I didn't understand your question. "
            "Try queries like 'mean of revenue', 'plot age vs salary', "
            "'sum of sales', 'trend of sales' or 'period comparison revenue'.", None)


def call_llm(prompt: str, df: pd.DataFrame) -> str | None:
    """
    Attempt to answer the user's question using an LLM (OpenAI or Anthropic) if
    API keys are configured.  The DataFrame is provided for context; it is
    summarised into a short description to guide the model.  If no API
    client is available or a call fails, returns None.

    Parameters
    ----------
    prompt : str
        The user's natural language question.
    df : pandas.DataFrame
        The current dataset, used to provide context to the model.

    Returns
    -------
    Optional[str]
        The answer from the LLM, or None if unavailable.
    """
    # Do not attempt if no model library is available or no API key is set
    # Check OpenAI first
    if openai is not None and os.getenv('OPENAI_API_KEY'):
        try:
            # Compose a context: summarise numeric columns and counts
            cols = ', '.join(df.columns.tolist()[:10])
            system_prompt = (
                "You are a data analyst assistant. Answer the user's question about the dataset. "
                "Provide concise and insightful responses based on the data."
            )
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Dataset columns: {cols}. Question: {prompt}"}
            ]
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo", messages=messages, temperature=0.2, max_tokens=150
            )
            answer = response.choices[0].message.content.strip()
            return answer
        except Exception:
            pass
    # Try Anthropic (Claude)
    if anthropic is not None and os.getenv('ANTHROPIC_API_KEY'):
        try:
            client = anthropic.Anthropic(api_key=os.getenv('ANTHROPIC_API_KEY'))
            prompt_text = (
                f"You are a helpful data analyst assistant. Dataset columns: {', '.join(df.columns.tolist()[:10])}. "
                f"Answer the question: {prompt}"
            )
            response = client.completions.create(model="claude-2", max_tokens=150, prompt=prompt_text)
            answer = response.completion.strip()
            return answer
        except Exception:
            pass
    return None


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Render the main page.

    The page displays a file upload form.  If a dataset is loaded in the
    application state, it additionally shows the preview table,
    summary statistics, a correlation heatmap, narrative text and the
    chat interface with existing history.
    """
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "dataset_loaded": state.dataset is not None,
            "preview_html": state.preview_html,
            "summary_html": state.summary_html,
            "corr_div": state.corr_div,
            "narrative": state.narrative,
            "chat_history": state.chat_history,
            "plotly_js": PLOTLY_JS,
            "numeric_columns": state.numeric_columns,
            "model_fig": state.model_fig,
            "model_metrics": state.model_metrics,
            "model_importance": state.model_importance,
            "hist_charts": state.hist_charts,
            "bar_charts": state.bar_charts,
            "time_series_charts": state.time_series_charts,
            "box_charts": state.box_charts,
            "scatter_matrix_charts": state.scatter_matrix_charts,
            "treemap_charts": state.treemap_charts,
            "violin_charts": state.violin_charts,
            "pie_charts": state.pie_charts,
            "categorical_columns": state.categorical_columns,
            "datetime_columns": state.datetime_columns,
            "all_columns": state.all_columns,
            "prediction_results": state.prediction_results,
        "actionable_insights": state.actionable_insights_html,
        "question_suggestions": state.question_suggestions,
        },
    )


@app.post("/upload", response_class=RedirectResponse)
async def upload_dataset(request: Request, file: UploadFile):
    """Handle file upload and compute analysis results.

    After loading the dataset, the function generates all analysis
    artefacts (preview table, summary stats, correlation heatmap,
    narrative) and resets the chat history.  The client is then
    redirected back to the main page to display the results.
    """
    try:
        df = load_dataset(file)
    except Exception as exc:
        # On failure, redirect back without loading dataset
        print(f"Failed to load dataset: {exc}")
        return RedirectResponse("/", status_code=303)

    # Update the global state
    state.dataset = df
    state.preview_html = generate_preview(df)
    state.summary_html = generate_summary(df)
    state.corr_div = generate_correlation_heatmap(df)
    state.narrative = generate_narrative(df)
    state.chat_history = []
    # Store numeric columns for predictive modelling. Only numeric columns
    # are allowed as target variables in the predictive module.  We compute
    # this list once when a new dataset is uploaded.
    try:
        state.numeric_columns = df.select_dtypes(include=[np.number]).columns.tolist()
    except Exception:
        # Fallback to None if something goes wrong
        state.numeric_columns = None
    # Reset any prior model outputs whenever a new dataset is uploaded
    state.model_fig = None
    state.model_metrics = None
    state.model_importance = None
    # Reset prediction results for advanced analytics
    state.prediction_results = None
    # Generate additional EDA charts
    state.hist_charts = generate_hist_charts(df)
    state.bar_charts = generate_bar_charts(df)
    state.time_series_charts = generate_time_series_charts(df)
    state.box_charts = generate_box_charts(df)
    # Generate additional charts for scatter matrix and treemap analysis
    state.scatter_matrix_charts = generate_scatter_matrix_charts(df)
    state.treemap_charts = generate_treemap_charts(df)

    # Additional charts: violin and pie charts
    state.violin_charts = generate_violin_charts(df)
    state.pie_charts = generate_pie_charts(df)

    # Store lists of columns for UI selectors
    try:
        state.categorical_columns = df.select_dtypes(include=['object', 'category']).columns.tolist()
    except Exception:
        state.categorical_columns = None
    try:
        state.datetime_columns = df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
    except Exception:
        state.datetime_columns = None
    try:
        state.all_columns = df.columns.tolist()
    except Exception:
        state.all_columns = None

    # Generate actionable insights and question suggestions after uploading dataset
    try:
        insights_html, suggestions = generate_actionable_insights(df, None)
        state.actionable_insights_html = insights_html
        state.question_suggestions = suggestions
    except Exception:
        state.actionable_insights_html = None
        state.question_suggestions = None

    # Redirect back to the index to show results
    return RedirectResponse("/", status_code=303)


@app.post("/query", response_class=HTMLResponse)
async def process_query(request: Request, user_query: str = Form(...)):
    """Process a user's chat query and return updated page.

    The user's query is answered using a simple parser in `handle_query`.
    The resulting answer is appended to the chat history.  The page is
    re‑rendered with the updated chat history and, if a chart is
    produced, the chart is included at the end of the chat.
    """
    if state.dataset is None:
        # No dataset loaded yet; show a message
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": False,
                "preview_html": None,
                "summary_html": None,
                "corr_div": None,
                "narrative": None,
                "chat_history": [],
                "error": "Please upload a dataset before asking questions.",
                "plotly_js": PLOTLY_JS,
            },
        )

    # Generate answer and optional chart
    answer_text, fig_div = handle_query(state.dataset, user_query)
    entry = {"user": user_query, "response": answer_text, "figure": fig_div}
    state.chat_history.append(entry)

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "dataset_loaded": True,
            "preview_html": state.preview_html,
            "summary_html": state.summary_html,
            "corr_div": state.corr_div,
            "narrative": state.narrative,
            "chat_history": state.chat_history,
            "plotly_js": PLOTLY_JS,
            "numeric_columns": state.numeric_columns,
            "model_fig": state.model_fig,
            "model_metrics": state.model_metrics,
            "model_importance": state.model_importance,
            "hist_charts": state.hist_charts,
            "bar_charts": state.bar_charts,
            "time_series_charts": state.time_series_charts,
            "box_charts": state.box_charts,
            "scatter_matrix_charts": state.scatter_matrix_charts,
            "treemap_charts": state.treemap_charts,
            "violin_charts": state.violin_charts,
            "pie_charts": state.pie_charts,
            "categorical_columns": state.categorical_columns,
            "datetime_columns": state.datetime_columns,
            "all_columns": state.all_columns,
            "prediction_results": state.prediction_results,
            "actionable_insights": state.actionable_insights_html,
            "question_suggestions": state.question_suggestions,
        },
    )


# New endpoint for building and visualising a predictive model
@app.post("/model", response_class=HTMLResponse)
async def build_model(
    request: Request,
    target_variable: str = Form(...),
    top_n: int = Form(5),
):
    """Build a predictive model for the selected target variable.

    The user selects a numeric column as the target and chooses how many
    top features to display.  A random forest model is trained and
    evaluated, and feature importances are shown.  Results are stored
    in the global state so that they persist across page reloads.
    """
    # Validate that a dataset has been loaded
    if state.dataset is None:
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": False,
                "preview_html": None,
                "summary_html": None,
                "corr_div": None,
                "narrative": None,
                "chat_history": [],
                "error": "Please upload a dataset before building a model.",
                "plotly_js": PLOTLY_JS,
                "numeric_columns": state.numeric_columns,
                "model_fig": state.model_fig,
                "model_metrics": state.model_metrics,
                "model_importance": state.model_importance,
                "hist_charts": state.hist_charts,
                "bar_charts": state.bar_charts,
                "time_series_charts": state.time_series_charts,
                "box_charts": state.box_charts,
                "scatter_matrix_charts": state.scatter_matrix_charts,
                "treemap_charts": state.treemap_charts,
                "violin_charts": state.violin_charts,
                "pie_charts": state.pie_charts,
            },
        )

    # Ensure the selected target variable exists and is numeric
    if state.numeric_columns is None or target_variable not in state.numeric_columns:
        # Provide an error message if invalid target selected
        error_msg = f"The target variable '{target_variable}' is not available or not numeric."
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": True,
                "preview_html": state.preview_html,
                "summary_html": state.summary_html,
                "corr_div": state.corr_div,
                "narrative": state.narrative,
                "chat_history": state.chat_history,
                "error": error_msg,
                "plotly_js": PLOTLY_JS,
                "numeric_columns": state.numeric_columns,
                "model_fig": state.model_fig,
                "model_metrics": state.model_metrics,
                "model_importance": state.model_importance,
                "hist_charts": state.hist_charts,
                "bar_charts": state.bar_charts,
                "time_series_charts": state.time_series_charts,
                "box_charts": state.box_charts,
                "scatter_matrix_charts": state.scatter_matrix_charts,
                "treemap_charts": state.treemap_charts,
                "violin_charts": state.violin_charts,
                "pie_charts": state.pie_charts,
            },
        )

    # Clamp top_n to a reasonable range (1-20)
    try:
        n_features = int(top_n)
        if n_features < 1:
            n_features = 1
        elif n_features > 20:
            n_features = 20
    except ValueError:
        n_features = 5

    # Build the model and get outputs
    try:
        fig_div, metrics_html, fi_table_html = build_predictive_model(
            state.dataset, target_variable, top_n=n_features
        )
        # Store results in global state
        state.model_fig = fig_div
        state.model_metrics = metrics_html
        state.model_importance = fi_table_html
    except Exception as exc:
        error_msg = f"Failed to build model: {exc}"
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": True,
                "preview_html": state.preview_html,
                "summary_html": state.summary_html,
                "corr_div": state.corr_div,
                "narrative": state.narrative,
                "chat_history": state.chat_history,
                "error": error_msg,
                "plotly_js": PLOTLY_JS,
                "numeric_columns": state.numeric_columns,
                "model_fig": state.model_fig,
                "model_metrics": state.model_metrics,
                "model_importance": state.model_importance,
                "hist_charts": state.hist_charts,
                "bar_charts": state.bar_charts,
                "time_series_charts": state.time_series_charts,
                "box_charts": state.box_charts,
                "scatter_matrix_charts": state.scatter_matrix_charts,
                "treemap_charts": state.treemap_charts,
            },
        )

    # Render the index template with updated context
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "dataset_loaded": True,
            "preview_html": state.preview_html,
            "summary_html": state.summary_html,
            "corr_div": state.corr_div,
            "narrative": state.narrative,
            "chat_history": state.chat_history,
            "plotly_js": PLOTLY_JS,
            "numeric_columns": state.numeric_columns,
            "model_fig": state.model_fig,
            "model_metrics": state.model_metrics,
            "model_importance": state.model_importance,
            "hist_charts": state.hist_charts,
            "bar_charts": state.bar_charts,
            "time_series_charts": state.time_series_charts,
            "box_charts": state.box_charts,
            "scatter_matrix_charts": state.scatter_matrix_charts,
            "treemap_charts": state.treemap_charts,
            "violin_charts": state.violin_charts,
            "pie_charts": state.pie_charts,
            "categorical_columns": state.categorical_columns,
            "datetime_columns": state.datetime_columns,
            "all_columns": state.all_columns,
            "prediction_results": state.prediction_results,
            "actionable_insights": state.actionable_insights_html,
            "question_suggestions": state.question_suggestions,
        },
    )


# Endpoint for running advanced predictive analytics
@app.post("/predict", response_class=HTMLResponse)
async def run_analytics(request: Request):
    """
    Run multi‑model predictive analytics based on user selections.

    The request form should include:
        - analysis_type: 'regression', 'classification' or 'timeseries'
        - target_variable: the column name to predict
        - date_column: (optional) for time series analysis
        - selected_features: optional list of feature column names (multiple)
        - feature_engineering: 'on' if feature engineering is enabled

    Results are stored in the application state and then rendered on the main page.
    """
    # Ensure dataset loaded
    if state.dataset is None:
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": False,
                "preview_html": None,
                "summary_html": None,
                "corr_div": None,
                "narrative": None,
                "chat_history": [],
                "error": "Please upload a dataset before running predictive analytics.",
                "plotly_js": PLOTLY_JS,
            },
        )
    # Parse form data
    form = await request.form()
    analysis_type = form.get("analysis_type")
    target_variable = form.get("target_variable")
    date_column = form.get("date_column")
    # selected_features may be provided as a comma‑separated string or multi‑select list
    selected_features = []
    # Multi‑select returns a tuple/list of values under the same key; also handle comma separation
    if 'selected_features' in form:
        # When using <select multiple>, each selection appears separately
        values = form.getlist('selected_features') if hasattr(form, 'getlist') else form.get('selected_features')
        if isinstance(values, (list, tuple)):
            selected_features = list(values)
        elif isinstance(values, str):
            selected_features = [v.strip() for v in values.split(',') if v.strip()]
    # Feature engineering flag
    feature_engineering_flag = form.get("feature_engineering")
    feature_engineering = feature_engineering_flag == 'on'
    # Validation
    if not analysis_type or not target_variable:
        error_msg = "Please select an analysis type and target variable."
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": True,
                "preview_html": state.preview_html,
                "summary_html": state.summary_html,
                "corr_div": state.corr_div,
                "narrative": state.narrative,
                "chat_history": state.chat_history,
                "error": error_msg,
                "plotly_js": PLOTLY_JS,
                "numeric_columns": state.numeric_columns,
                "hist_charts": state.hist_charts,
                "bar_charts": state.bar_charts,
                "time_series_charts": state.time_series_charts,
                "box_charts": state.box_charts,
                "scatter_matrix_charts": state.scatter_matrix_charts,
                "treemap_charts": state.treemap_charts,
                "violin_charts": state.violin_charts,
                "pie_charts": state.pie_charts,
                "categorical_columns": state.categorical_columns,
                "datetime_columns": state.datetime_columns,
                "all_columns": state.all_columns,
                "prediction_results": state.prediction_results,
                "actionable_insights": state.actionable_insights_html,
                "question_suggestions": state.question_suggestions,
            },
        )
    # Run models
    try:
        results = run_predictive_models(
            state.dataset,
            analysis_type=analysis_type,
            target=target_variable,
            selected_features=selected_features,
            date_col=date_column,
            feature_engineering=feature_engineering,
        )
        state.prediction_results = results
        # Update actionable insights and suggestions after predictive modelling
        try:
            insights_html, suggestions = generate_actionable_insights(state.dataset, state.prediction_results)
            state.actionable_insights_html = insights_html
            state.question_suggestions = suggestions
        except Exception:
            state.actionable_insights_html = None
            state.question_suggestions = None
    except Exception as exc:
        error_msg = f"Predictive analytics failed: {exc}"
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": True,
                "preview_html": state.preview_html,
                "summary_html": state.summary_html,
                "corr_div": state.corr_div,
                "narrative": state.narrative,
                "chat_history": state.chat_history,
                "error": error_msg,
                "plotly_js": PLOTLY_JS,
                "numeric_columns": state.numeric_columns,
                "hist_charts": state.hist_charts,
                "bar_charts": state.bar_charts,
                "time_series_charts": state.time_series_charts,
                "box_charts": state.box_charts,
                "scatter_matrix_charts": state.scatter_matrix_charts,
                "treemap_charts": state.treemap_charts,
                "violin_charts": state.violin_charts,
                "pie_charts": state.pie_charts,
                "categorical_columns": state.categorical_columns,
                "datetime_columns": state.datetime_columns,
                "all_columns": state.all_columns,
                "prediction_results": state.prediction_results,
            },
        )
    # Render with updated prediction results
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "dataset_loaded": True,
            "preview_html": state.preview_html,
            "summary_html": state.summary_html,
            "corr_div": state.corr_div,
            "narrative": state.narrative,
            "chat_history": state.chat_history,
            "plotly_js": PLOTLY_JS,
            "numeric_columns": state.numeric_columns,
            "hist_charts": state.hist_charts,
            "bar_charts": state.bar_charts,
            "time_series_charts": state.time_series_charts,
            "box_charts": state.box_charts,
            "scatter_matrix_charts": state.scatter_matrix_charts,
            "treemap_charts": state.treemap_charts,
            "violin_charts": state.violin_charts,
            "pie_charts": state.pie_charts,
            "categorical_columns": state.categorical_columns,
            "datetime_columns": state.datetime_columns,
            "all_columns": state.all_columns,
            "prediction_results": state.prediction_results,
            "actionable_insights": state.actionable_insights_html,
            "question_suggestions": state.question_suggestions,
        },
    )