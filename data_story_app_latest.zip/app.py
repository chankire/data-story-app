"""
data_story_app/app.py
======================

This module implements a lightweight data‑analysis and storytelling web
application using FastAPI and Jinja2.  The application allows users to
upload a CSV file, automatically profiles the uploaded dataset and
displays exploratory data analysis (EDA) results such as descriptive
statistics, a correlation heatmap and a simple narrative summarising
interesting findings.  A rudimentary chat interface is also provided
allowing users to ask basic questions about the data (e.g. "mean of
revenue" or "plot age vs salary").  Responses to these queries are
generated using simple pattern matching against the uploaded dataset.

The resulting application can be launched locally via

    uvicorn app:app --reload

Once running, navigate to `http://localhost:8000/` in your web browser
to interact with the interface.  The server keeps the uploaded dataset
and chat state in memory for the lifetime of the process (no
persistence layer is implemented), so this example is suitable for
demonstration purposes but not for production deployment.

Prerequisites:
    - Python 3.8+
    - fastapi
    - uvicorn
    - jinja2
    - pandas
    - plotly (for interactive charts)

All of these packages are installed in the provided container, but if
you're running this code outside the container you should install
them via pip.  A minimal requirements.txt is provided in the
repository root for convenience.
"""

from fastapi import FastAPI, Request, UploadFile, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.offline as po
from io import StringIO
import re
import os

# Try to import optional LLM clients for natural language answers.
try:
    import openai  # type: ignore
except Exception:
    openai = None  # type: ignore
try:
    import anthropic  # type: ignore
except Exception:
    anthropic = None  # type: ignore

# Import get_plotlyjs to embed the script into the HTML so that
# charts work without an external network connection.  The returned
# string contains a minified copy of the Plotly JavaScript library.
from plotly.offline import get_plotlyjs


# Instantiate the FastAPI app
app = FastAPI(title="Data Story App")

# Set up Jinja2 templates; templates live in the `templates` directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

# Mount a static directory for serving assets (optional)
static_dir = os.path.join(BASE_DIR, "static")
if not os.path.exists(static_dir):
    os.makedirs(static_dir, exist_ok=True)
app.mount("/static", StaticFiles(directory=static_dir), name="static")

# In‑memory state for the currently loaded dataset and chat history.
# In a production system you'd implement proper per‑session storage or a
# database instead of these module‑level variables.
class AppState:
    dataset: pd.DataFrame | None = None
    preview_html: str | None = None
    summary_html: str | None = None
    corr_div: str | None = None
    narrative: str | None = None
    chat_history: list[dict] = []
    # Numeric columns detected in the currently loaded dataset. Used for target variable selection.
    numeric_columns: list[str] | None = None
    # Fields for storing predictive model outputs
    model_fig: str | None = None
    model_metrics: str | None = None
    model_importance: str | None = None

    # Additional exploratory analysis artefacts
    # Each list contains dicts with keys: 'title', 'figure', 'summary'
    hist_charts: list | None = None
    bar_charts: list | None = None
    time_series_charts: list | None = None
    box_charts: list | None = None

    # Scatter matrix charts for exploring pairwise relationships
    scatter_matrix_charts: list | None = None
    # Treemap charts for visualising category contributions to a numeric metric
    treemap_charts: list | None = None


state = AppState()

# Embed plotly.js into the template to avoid external network calls.
PLOTLY_JS = get_plotlyjs()


def load_dataset(file: UploadFile) -> pd.DataFrame:
    """Load a dataset from an uploaded file.

    Currently supports CSV files.  XLSX files could be added easily by
    checking file.content_type and using pandas.read_excel.

    Parameters
    ----------
    file : UploadFile
        The uploaded file object.

    Returns
    -------
    pd.DataFrame
        The loaded data.
    """
    # Read the file contents into a pandas DataFrame
    contents = file.file.read().decode("utf-8", errors="ignore")
    # Use StringIO to simulate a file handle for pandas
    data = pd.read_csv(StringIO(contents))
    return data


def generate_preview(df: pd.DataFrame, max_rows: int = 5) -> str:
    """Generate an HTML table preview of the first few rows."""
    preview_df = df.head(max_rows).copy()
    return preview_df.to_html(classes="dataframe table table-striped table-bordered", index=False, border=0)


def build_predictive_model(df: pd.DataFrame, target: str, top_n: int = 5):
    """Train a random forest model to predict the given target variable.

    This function automatically handles categorical and datetime columns using one‑hot encoding and
    extracting year/month/day components from datetimes. It returns a tuple containing:
    - an HTML div containing a Plotly bar chart of the top features,
    - an HTML string summarising model evaluation metrics,
    - an HTML table of the top feature importances.

    Parameters
    ----------
    df : pandas.DataFrame
        The dataset containing both features and target.
    target : str
        The name of the target variable to predict.
    top_n : int, default 5
        Number of top features to display.

    Returns
    -------
    tuple[str, str, str]
        fig_div, metrics_html, feature_importance_table_html
    """
    import numpy as np
    import pandas as pd
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import OneHotEncoder
    from sklearn.compose import ColumnTransformer
    from sklearn.pipeline import Pipeline
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    import plotly.express as px
    import plotly.offline as po

    # Create copies to avoid modifying original data
    data = df.copy()
    y = data.pop(target)
    X = data

    # Identify categorical, datetime, and numeric columns
    cat_cols = X.select_dtypes(include=['object']).columns.tolist()
    datetime_cols = X.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
    num_cols = X.select_dtypes(include=[np.number]).columns.tolist()

    # Extract date parts from datetime columns
    for col in datetime_cols:
        X[f"{col}_year"] = X[col].dt.year
        X[f"{col}_month"] = X[col].dt.month
        X[f"{col}_day"] = X[col].dt.day
    # Drop original datetime columns
    X.drop(columns=datetime_cols, inplace=True)
    # Update numeric feature list after expanding datetimes
    num_cols = [c for c in X.columns if c not in cat_cols]

    # Preprocess: one‑hot encode categorical variables, pass through numeric variables
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore'), cat_cols),
            ('num', 'passthrough', num_cols)
        ]
    )

    # Define model pipeline
    model = Pipeline([
        ('preprocessor', preprocessor),
        ('rf', RandomForestRegressor(n_estimators=200, random_state=42))
    ])

    # Train‑test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Fit model
    model.fit(X_train, y_train)

    # Predict and compute metrics
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    mse = mean_squared_error(y_test, preds)
    r2 = r2_score(y_test, preds)
    metrics_html = (
        f"<p><strong>Model Evaluation Metrics:</strong></p>"
        f"<ul>"
        f"<li>Mean Absolute Error (MAE): {mae:.2f}</li>"
        f"<li>Mean Squared Error (MSE): {mse:.2f}</li>"
        f"<li>R-squared (R²): {r2:.3f}</li>"
        f"</ul>"
    )

    # Extract feature names after preprocessing
    encoder = model.named_steps['preprocessor'].transformers_[0][1]
    encoded_cat_cols = encoder.get_feature_names_out(cat_cols)
    feature_names = list(encoded_cat_cols) + num_cols
    # Feature importances
    importances = model.named_steps['rf'].feature_importances_
    fi_df = pd.DataFrame({'Feature': feature_names, 'Importance': importances})
    fi_df.sort_values(by='Importance', ascending=False, inplace=True)
    top_features = fi_df.head(top_n)

    # Create Plotly bar chart for feature importances
    fig = px.bar(top_features.iloc[::-1], x='Importance', y='Feature', orientation='h',
                 title=f'Top {top_n} Feature Importances for predicting {target}')
    fig.update_layout(height=400, margin=dict(l=0, r=0, t=30, b=0))
    fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')

    # Convert top features to HTML table
    fi_table_html = top_features.to_html(classes='dataframe table table-striped table-bordered', index=False, border=0)

    return fig_div, metrics_html, fi_table_html


def generate_hist_charts(df: pd.DataFrame, max_cols: int = 3) -> list[dict]:
    """
    Generate histogram charts for up to `max_cols` numeric columns.

    Each entry in the returned list is a dictionary containing the chart title,
    the Plotly figure div (HTML) and a short textual summary highlighting
    descriptive statistics for the column.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of numeric columns to visualise. Defaults to 3.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.
    """
    charts: list[dict] = []
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not numeric_cols:
        return charts
    for col in numeric_cols[:max_cols]:
        try:
            fig = px.histogram(df, x=col, nbins=20, title=f"Distribution of {col}")
            fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            mean = df[col].mean()
            median = df[col].median()
            minimum = df[col].min()
            maximum = df[col].max()
            summary = (
                f"The distribution of <strong>{col}</strong> ranges from {minimum:.2f} to {maximum:.2f}. "
                f"The mean is {mean:.2f} and the median is {median:.2f}."
            )
            charts.append({"title": f"Distribution of {col}", "figure": fig_div, "summary": summary})
        except Exception:
            # Skip problematic columns silently
            continue
    return charts


def generate_bar_charts(df: pd.DataFrame, max_cols: int = 3, top_n: int = 10) -> list[dict]:
    """
    Generate bar charts for up to `max_cols` categorical columns showing the
    distribution of the most frequent categories.

    Each entry in the returned list is a dictionary containing the chart title,
    the Plotly figure div and a short summary describing the most common
    category.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of categorical columns to visualise. Defaults to 3.
    top_n : int, optional
        Number of top categories to display. Defaults to 10.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.
    """
    charts: list[dict] = []
    cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    if not cat_cols:
        return charts
    for col in cat_cols[:max_cols]:
        try:
            counts = df[col].value_counts().nlargest(top_n)
            # Create bar chart
            fig = px.bar(
                x=counts.index.astype(str),
                y=counts.values,
                title=f"Top {min(top_n, len(counts))} categories in {col}",
                labels={'x': col, 'y': 'Count'},
            )
            fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            top_cat = counts.index[0]
            top_count = counts.iloc[0]
            summary = f"The most common value in <strong>{col}</strong> is <strong>{top_cat}</strong> with {top_count} occurrences."
            charts.append({"title": f"{col} distribution", "figure": fig_div, "summary": summary})
        except Exception:
            continue
    return charts


def generate_time_series_charts(df: pd.DataFrame) -> list[dict]:
    """
    Generate line charts for time series analysis on the first datetime column
    and a few numeric columns.

    If a datetime column exists, we aggregate numeric columns by date and
    produce a line chart for the first numeric column.  A summary describing
    the overall trend is also generated.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.  If no datetime
        column is present, returns an empty list.
    """
    charts: list[dict] = []
    datetime_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not datetime_cols or not numeric_cols:
        return charts
    date_col = datetime_cols[0]
    metric_col = numeric_cols[0]
    try:
        # Ensure date column is a datetime index
        ts_df = df[[date_col, metric_col]].dropna().copy()
        ts_df[date_col] = pd.to_datetime(ts_df[date_col])
        ts_df.set_index(date_col, inplace=True)
        # Resample by day (D) if data spans multiple days, else by original frequency
        # Use sum for aggregation; users may modify as needed
        aggregated = ts_df.resample('D')[metric_col].sum().dropna()
        if aggregated.empty:
            return charts
        first_val = aggregated.iloc[0]
        last_val = aggregated.iloc[-1]
        change = ((last_val - first_val) / first_val) * 100 if first_val != 0 else 0
        direction = "increased" if change >= 0 else "decreased"
        summary = (
            f"From {aggregated.index.min().date()} to {aggregated.index.max().date()}, "
            f"the total <strong>{metric_col}</strong> {direction} by {abs(change):.2f}%. "
            f"It went from {first_val:.2f} to {last_val:.2f}."
        )
        # Create line chart
        fig = px.line(
            x=aggregated.index,
            y=aggregated.values,
            title=f"Trend of {metric_col} over time",
            labels={'x': date_col, 'y': metric_col}
        )
        fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        charts.append({
            "title": f"Trend of {metric_col} by date",
            "figure": fig_div,
            "summary": summary
        })
    except Exception:
        pass
    return charts


def generate_box_charts(df: pd.DataFrame, max_cols: int = 3) -> list[dict]:
    """
    Generate box plots for up to `max_cols` numeric columns.

    Box plots provide additional insight beyond histograms by showing the
    interquartile range, median and outliers.  For each selected numeric
    column this function builds a Plotly box chart and crafts a short
    summary describing the median, quartiles and range.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of numeric columns to visualise. Defaults to 3.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.
    """
    charts: list[dict] = []
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not numeric_cols:
        return charts
    # Only include up to max_cols numeric columns
    for col in numeric_cols[:max_cols]:
        try:
            # Create box plot
            fig = px.box(df, y=col, points='outliers', title=f"Box Plot of {col}")
            fig.update_layout(height=400, margin=dict(l=0, r=0, t=40, b=0))
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            # Compute statistics
            series = df[col].dropna()
            median = series.median()
            q1 = series.quantile(0.25)
            q3 = series.quantile(0.75)
            minimum = series.min()
            maximum = series.max()
            summary = (
                f"The box plot for <strong>{col}</strong> shows a median of {median:.2f}, "
                f"with the 25th percentile at {q1:.2f} and the 75th percentile at {q3:.2f}. "
                f"Values range from {minimum:.2f} to {maximum:.2f}."
            )
            charts.append({"title": f"Box Plot of {col}", "figure": fig_div, "summary": summary})
        except Exception:
            continue
    return charts


def generate_scatter_matrix_charts(df: pd.DataFrame, max_cols: int = 4) -> list[dict]:
    """
    Generate a scatter matrix (pairwise scatter plots) for up to `max_cols` numeric columns.

    A scatter matrix allows users to visually inspect relationships between multiple numeric
    variables simultaneously.  For each generated matrix, this function also computes
    pairwise correlations and highlights the strongest relationship in the summary.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cols : int, optional
        Maximum number of numeric columns to include in the scatter matrix. Defaults to 4.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.  If there are fewer than
        two numeric columns, returns an empty list.
    """
    charts: list[dict] = []
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if len(numeric_cols) < 2:
        return charts
    # Use only the first max_cols numeric columns
    cols = numeric_cols[:max_cols]
    try:
        # Compute correlation matrix for summary
        corr_matrix = df[cols].corr().abs()
        # Find the strongest off-diagonal correlation
        upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        max_corr = upper_tri.stack().sort_values(ascending=False)
        if not max_corr.empty:
            best_pair = max_corr.index[0]
            best_val = max_corr.iloc[0]
            summary = (
                f"The scatter matrix shows pairwise relationships among {len(cols)} variables. "
                f"The strongest correlation is between <strong>{best_pair[0]}</strong> and "
                f"<strong>{best_pair[1]}</strong> with a correlation of {best_val:.2f}."
            )
        else:
            summary = "The scatter matrix shows weak correlations among the selected variables."
        fig = px.scatter_matrix(df[cols], dimensions=cols, title="Scatter Matrix for Selected Numeric Columns")
        fig.update_layout(height=600, width=600, margin=dict(l=0, r=0, t=40, b=0))
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        charts.append({"title": "Scatter Matrix", "figure": fig_div, "summary": summary})
    except Exception:
        pass
    return charts


def generate_treemap_charts(df: pd.DataFrame, max_cats: int = 1, agg_func: str = 'sum') -> list[dict]:
    """
    Generate treemap charts to visualise how categorical groups contribute to a numeric metric.

    This function selects the first categorical column and up to the first numeric column,
    aggregates the numeric metric by category using the specified aggregation function, and
    builds a treemap.  A short summary highlights the dominant category and its share.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame.
    max_cats : int, optional
        Maximum number of categorical columns to consider. Defaults to 1.
    agg_func : str, optional
        Aggregation function to apply to the numeric metric (e.g. 'sum' or 'mean'). Defaults to 'sum'.

    Returns
    -------
    list of dict
        Each dict has keys 'title', 'figure' and 'summary'.  Returns empty list if
        no suitable categorical or numeric columns are found.
    """
    charts: list[dict] = []
    cat_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if not cat_cols or not num_cols:
        return charts
    # Use only the first categorical and first numeric column for simplicity
    cat_col = cat_cols[0]
    num_col = num_cols[0]
    try:
        # Aggregate the numeric column by category
        if agg_func == 'mean':
            agg_series = df.groupby(cat_col)[num_col].mean()
            agg_name = f"average {num_col}"
        else:
            agg_series = df.groupby(cat_col)[num_col].sum()
            agg_name = f"total {num_col}"
        agg_series = agg_series.sort_values(ascending=False)
        # Compute share for summary
        total_val = agg_series.sum()
        if total_val > 0:
            top_cat = agg_series.index[0]
            top_val = agg_series.iloc[0]
            share = (top_val / total_val) * 100
            summary = (
                f"The treemap visualises {agg_name} by {cat_col}. "
                f"<strong>{top_cat}</strong> accounts for {share:.1f}% of the overall {agg_name}."
            )
        else:
            summary = f"All categories have zero total {num_col}."
        # Create treemap figure
        fig = px.treemap(
            names=agg_series.index.astype(str),
            values=agg_series.values,
            title=f"Treemap of {agg_name} by {cat_col}",
            labels={"names": cat_col, "values": agg_name}
        )
        fig.update_layout(height=500, margin=dict(l=0, r=0, t=40, b=0))
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        charts.append({"title": f"Treemap of {agg_name} by {cat_col}", "figure": fig_div, "summary": summary})
    except Exception:
        pass
    return charts


def generate_summary(df: pd.DataFrame) -> str:
    """Compute descriptive statistics for numeric columns and render as HTML."""
    # Only include numeric columns for summary statistics
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.empty:
        return "<p>No numeric columns available for summary statistics.</p>"
    desc = numeric_df.describe().transpose()
    desc.reset_index(inplace=True)
    desc.rename(columns={"index": "column"}, inplace=True)
    # Round statistics for readability
    desc = desc.round(3)
    return desc.to_html(classes="dataframe table table-striped table-bordered", index=False, border=0)


def generate_correlation_heatmap(df: pd.DataFrame) -> str:
    """Create a Plotly correlation heatmap and return HTML div."""
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.shape[1] < 2:
        return ""
    corr_matrix = numeric_df.corr()
    fig = px.imshow(
        corr_matrix,
        text_auto=False,
        aspect="auto",
        labels=dict(color="Correlation"),
        x=corr_matrix.columns,
        y=corr_matrix.index,
        title="Correlation Heatmap"
    )
    fig.update_layout(height=500)
    # Convert Plotly figure to an HTML div string.  We exclude the
    # Plotly.js library here to avoid multiple inclusions on the page; the
    # script is included once in the base template.
    heatmap_div = po.plot(fig, include_plotlyjs=False, output_type='div')
    return heatmap_div


def generate_narrative(df: pd.DataFrame) -> str:
    """Generate a simple textual narrative summarising the dataset.

    This heuristic narrative calls out interesting aspects of the data:
    the number of rows/columns, the column with the most missing values,
    columns with the largest mean values, and highly correlated pairs.

    Returns an HTML string.
    """
    n_rows, n_cols = df.shape
    numeric_df = df.select_dtypes(include=[np.number])
    narrative_parts = []

    # Data size
    narrative_parts.append(
        f"<p>Your dataset contains <strong>{n_rows}</strong> rows and <strong>{n_cols}</strong> columns.</p>"
    )

    # Missing values
    missing_counts = df.isna().sum()
    if missing_counts.sum() > 0:
        max_missing_col = missing_counts.idxmax()
        max_missing_count = missing_counts[max_missing_col]
        narrative_parts.append(
            f"<p>The column with the most missing values is <strong>{max_missing_col}</strong> "
            f"with <strong>{int(max_missing_count)}</strong> missing entries.</p>"
        )
    else:
        narrative_parts.append("<p>There are no missing values in this dataset.</p>")

    # Largest mean values
    if not numeric_df.empty:
        means = numeric_df.mean().sort_values(ascending=False)
        top_means = means.head(min(3, len(means)))
        top_mean_phrases = [f"<strong>{col}</strong> (mean={val:.2f})" for col, val in top_means.items()]
        narrative_parts.append(
            "<p>The columns with the highest mean values are: " + ", ".join(top_mean_phrases) + ".</p>"
        )

        # Highly correlated pairs
        corr_matrix = numeric_df.corr().abs()
        # Select upper triangle of correlation matrix to avoid duplicates and self correlations
        upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        # Identify pairs above threshold
        threshold = 0.8
        high_corr = [(col1, col2, val) for col1 in upper_tri.columns for col2, val in upper_tri[col1].dropna().items() if val >= threshold]
        if high_corr:
            phrases = [f"<strong>{c1}</strong> and <strong>{c2}</strong> (corr={val:.2f})" for c1, c2, val in high_corr]
            narrative_parts.append(
                "<p>Highly correlated column pairs include: " + "; ".join(phrases) + ".</p>"
            )

    return "\n".join(narrative_parts)


def handle_query(df: pd.DataFrame, query: str) -> tuple[str, str | None]:
    """Interpret a simple natural language query and return a response.

    The function looks for patterns such as 'mean of column', 'median of column',
    'sum of column', 'max of column', 'min of column', 'plot col1 vs col2',
    'plot distribution of column', 'correlation between col1 and col2', and
    'count' (number of rows).

    It returns a tuple consisting of the textual answer and an optional
    Plotly figure represented as an HTML div string.  If the query could
    not be parsed, a message is returned along with None.

    Parameters
    ----------
    df : pd.DataFrame
        The dataset to query.
    query : str
        The user's freeform question.

    Returns
    -------
    Tuple[str, Optional[str]]
        A textual answer and optionally an HTML div for a chart.
    """
    # Lowercase the query for easier matching
    q = query.strip().lower()

    # Handle count
    if re.fullmatch(r"(number of rows|count)", q):
        return (f"The dataset contains {df.shape[0]} rows.", None)

    # Mean
    m = re.match(r"mean of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The mean of {col} is {df[col].mean():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Median
    m = re.match(r"median of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The median of {col} is {df[col].median():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Sum
    m = re.match(r"sum of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The sum of {col} is {df[col].sum():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Max
    m = re.match(r"max(?:imum)? of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The maximum of {col} is {df[col].max():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Min
    m = re.match(r"min(?:imum)? of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The minimum of {col} is {df[col].min():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Correlation between columns
    m = re.match(r"corr(?:elation)? between ([\w\s]+) and ([\w\s]+)", q)
    if m:
        col1 = m.group(1).strip()
        col2 = m.group(2).strip()
        if (col1 in df.columns and col2 in df.columns and 
                pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2])):
            corr_val = df[col1].corr(df[col2])
            return (f"The correlation between {col1} and {col2} is {corr_val:.3f}.", None)
        else:
            return (f"One or both columns not found or not numeric.", None)

    # Histogram / distribution
    m = re.match(r"(plot|show) (?:the )?(?:distribution|histogram) of ([\w\s]+)", q)
    if m:
        col = m.group(2).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            fig = px.histogram(df, x=col, nbins=20, title=f"Distribution of {col}")
            fig.update_layout(height=400)
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            return (f"Here is the distribution of {col}.", fig_div)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Scatter plot
    m = re.match(r"(plot|show) ([\w\s]+) vs ([\w\s]+)", q)
    if m:
        col1 = m.group(2).strip()
        col2 = m.group(3).strip()
        if (col1 in df.columns and col2 in df.columns and 
                pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2])):
            fig = px.scatter(df, x=col1, y=col2, title=f"{col1} vs {col2}")
            fig.update_layout(height=400)
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            return (f"Here is the scatter plot of {col1} vs {col2}.", fig_div)
        else:
            return (f"One or both columns not found or not numeric.", None)

    # Trend analysis query: plot the trend of a numeric column over the first datetime column
    m = re.match(r"(?:trend(?: of)?|plot trend of|show trend of) ([\w\s]+)", q)
    if m:
        target_col = m.group(1).strip()
        # Identify date column
        datetime_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
        if not datetime_cols:
            return ("No datetime column found for trend analysis.", None)
        if target_col not in df.columns or not pd.api.types.is_numeric_dtype(df[target_col]):
            return (f"Column '{target_col}' not found or is not numeric.", None)
        date_col = datetime_cols[0]
        ts_df = df[[date_col, target_col]].dropna().copy()
        ts_df[date_col] = pd.to_datetime(ts_df[date_col])
        ts_df.set_index(date_col, inplace=True)
        aggregated = ts_df.resample('D')[target_col].sum().dropna()
        if aggregated.empty:
            return ("Not enough data to compute trend.", None)
        first_val = aggregated.iloc[0]
        last_val = aggregated.iloc[-1]
        change = ((last_val - first_val) / first_val) * 100 if first_val != 0 else 0
        direction = "increased" if change >= 0 else "decreased"
        summary = (
            f"From {aggregated.index.min().date()} to {aggregated.index.max().date()}, the total {target_col} {direction} by {abs(change):.2f}% "
            f"(from {first_val:.2f} to {last_val:.2f})."
        )
        fig = px.line(x=aggregated.index, y=aggregated.values, title=f"Trend of {target_col} over time", labels={'x': date_col, 'y': target_col})
        fig.update_layout(height=400)
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        return (summary, fig_div)

    # Period comparison query: compare the last two periods (months) of a numeric column
    m = re.match(r"(?:period comparison|compare periods|period change) ([\w\s]+)", q)
    if m:
        target_col = m.group(1).strip()
        # Identify date column
        datetime_cols = df.select_dtypes(include=['datetime64[ns]', 'datetime64[ns, UTC]']).columns.tolist()
        if not datetime_cols:
            return ("No datetime column found for period comparison.", None)
        if target_col not in df.columns or not pd.api.types.is_numeric_dtype(df[target_col]):
            return (f"Column '{target_col}' not found or is not numeric.", None)
        date_col = datetime_cols[0]
        temp_df = df[[date_col, target_col]].dropna().copy()
        temp_df[date_col] = pd.to_datetime(temp_df[date_col])
        temp_df.set_index(date_col, inplace=True)
        # Aggregate monthly sums
        monthly = temp_df.resample('M')[target_col].sum().dropna()
        if len(monthly) < 2:
            return ("Not enough data for period comparison.", None)
        last_two = monthly.tail(2)
        period_names = [d.strftime('%Y-%m') for d in last_two.index]
        values = last_two.values
        difference = values[-1] - values[-2]
        pct_change = ((values[-1] - values[-2]) / values[-2]) * 100 if values[-2] != 0 else 0
        direction = "higher" if values[-1] >= values[-2] else "lower"
        summary = (
            f"In {period_names[1]}, {target_col} was {values[-1]:.2f}, which is {direction} than {period_names[0]} by {abs(difference):.2f} "
            f"({abs(pct_change):.2f}% change)."
        )
        # Bar chart showing the two periods
        fig = px.bar(x=period_names, y=values, title=f"{target_col} comparison of last two months", labels={'x': 'Period', 'y': target_col})
        fig.update_layout(height=400)
        fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
        return (summary, fig_div)

    # Fallback
    # If the query is not recognised by our patterns, attempt to call an LLM API
    llm_answer = call_llm(query, df)
    if llm_answer is not None:
        return (llm_answer, None)
    # Default fallback message
    return ("I'm sorry, I didn't understand your question. "
            "Try queries like 'mean of revenue', 'plot age vs salary', "
            "'sum of sales', 'trend of sales' or 'period comparison revenue'.", None)


def call_llm(prompt: str, df: pd.DataFrame) -> str | None:
    """
    Attempt to answer the user's question using an LLM (OpenAI or Anthropic) if
    API keys are configured.  The DataFrame is provided for context; it is
    summarised into a short description to guide the model.  If no API
    client is available or a call fails, returns None.

    Parameters
    ----------
    prompt : str
        The user's natural language question.
    df : pandas.DataFrame
        The current dataset, used to provide context to the model.

    Returns
    -------
    Optional[str]
        The answer from the LLM, or None if unavailable.
    """
    # Do not attempt if no model library is available or no API key is set
    # Check OpenAI first
    if openai is not None and os.getenv('OPENAI_API_KEY'):
        try:
            # Compose a context: summarise numeric columns and counts
            cols = ', '.join(df.columns.tolist()[:10])
            system_prompt = (
                "You are a data analyst assistant. Answer the user's question about the dataset. "
                "Provide concise and insightful responses based on the data."
            )
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Dataset columns: {cols}. Question: {prompt}"}
            ]
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo", messages=messages, temperature=0.2, max_tokens=150
            )
            answer = response.choices[0].message.content.strip()
            return answer
        except Exception:
            pass
    # Try Anthropic (Claude)
    if anthropic is not None and os.getenv('ANTHROPIC_API_KEY'):
        try:
            client = anthropic.Anthropic(api_key=os.getenv('ANTHROPIC_API_KEY'))
            prompt_text = (
                f"You are a helpful data analyst assistant. Dataset columns: {', '.join(df.columns.tolist()[:10])}. "
                f"Answer the question: {prompt}"
            )
            response = client.completions.create(model="claude-2", max_tokens=150, prompt=prompt_text)
            answer = response.completion.strip()
            return answer
        except Exception:
            pass
    return None


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Render the main page.

    The page displays a file upload form.  If a dataset is loaded in the
    application state, it additionally shows the preview table,
    summary statistics, a correlation heatmap, narrative text and the
    chat interface with existing history.
    """
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "dataset_loaded": state.dataset is not None,
            "preview_html": state.preview_html,
            "summary_html": state.summary_html,
            "corr_div": state.corr_div,
            "narrative": state.narrative,
            "chat_history": state.chat_history,
            "plotly_js": PLOTLY_JS,
            "numeric_columns": state.numeric_columns,
            "model_fig": state.model_fig,
            "model_metrics": state.model_metrics,
            "model_importance": state.model_importance,
            "hist_charts": state.hist_charts,
            "bar_charts": state.bar_charts,
            "time_series_charts": state.time_series_charts,
            "box_charts": state.box_charts,
            "scatter_matrix_charts": state.scatter_matrix_charts,
            "treemap_charts": state.treemap_charts,
        },
    )


@app.post("/upload", response_class=RedirectResponse)
async def upload_dataset(request: Request, file: UploadFile):
    """Handle file upload and compute analysis results.

    After loading the dataset, the function generates all analysis
    artefacts (preview table, summary stats, correlation heatmap,
    narrative) and resets the chat history.  The client is then
    redirected back to the main page to display the results.
    """
    try:
        df = load_dataset(file)
    except Exception as exc:
        # On failure, redirect back without loading dataset
        print(f"Failed to load dataset: {exc}")
        return RedirectResponse("/", status_code=303)

    # Update the global state
    state.dataset = df
    state.preview_html = generate_preview(df)
    state.summary_html = generate_summary(df)
    state.corr_div = generate_correlation_heatmap(df)
    state.narrative = generate_narrative(df)
    state.chat_history = []
    # Store numeric columns for predictive modelling. Only numeric columns
    # are allowed as target variables in the predictive module.  We compute
    # this list once when a new dataset is uploaded.
    try:
        state.numeric_columns = df.select_dtypes(include=[np.number]).columns.tolist()
    except Exception:
        # Fallback to None if something goes wrong
        state.numeric_columns = None
    # Reset any prior model outputs whenever a new dataset is uploaded
    state.model_fig = None
    state.model_metrics = None
    state.model_importance = None
    # Generate additional EDA charts
    state.hist_charts = generate_hist_charts(df)
    state.bar_charts = generate_bar_charts(df)
    state.time_series_charts = generate_time_series_charts(df)
    state.box_charts = generate_box_charts(df)
    # Generate additional charts for scatter matrix and treemap analysis
    state.scatter_matrix_charts = generate_scatter_matrix_charts(df)
    state.treemap_charts = generate_treemap_charts(df)

    # Redirect back to the index to show results
    return RedirectResponse("/", status_code=303)


@app.post("/query", response_class=HTMLResponse)
async def process_query(request: Request, user_query: str = Form(...)):
    """Process a user's chat query and return updated page.

    The user's query is answered using a simple parser in `handle_query`.
    The resulting answer is appended to the chat history.  The page is
    re‑rendered with the updated chat history and, if a chart is
    produced, the chart is included at the end of the chat.
    """
    if state.dataset is None:
        # No dataset loaded yet; show a message
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": False,
                "preview_html": None,
                "summary_html": None,
                "corr_div": None,
                "narrative": None,
                "chat_history": [],
                "error": "Please upload a dataset before asking questions.",
                "plotly_js": PLOTLY_JS,
            },
        )

    # Generate answer and optional chart
    answer_text, fig_div = handle_query(state.dataset, user_query)
    entry = {"user": user_query, "response": answer_text, "figure": fig_div}
    state.chat_history.append(entry)

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "dataset_loaded": True,
            "preview_html": state.preview_html,
            "summary_html": state.summary_html,
            "corr_div": state.corr_div,
            "narrative": state.narrative,
            "chat_history": state.chat_history,
            "plotly_js": PLOTLY_JS,
            "numeric_columns": state.numeric_columns,
            "model_fig": state.model_fig,
            "model_metrics": state.model_metrics,
            "model_importance": state.model_importance,
            "hist_charts": state.hist_charts,
            "bar_charts": state.bar_charts,
            "time_series_charts": state.time_series_charts,
            "box_charts": state.box_charts,
            "scatter_matrix_charts": state.scatter_matrix_charts,
            "treemap_charts": state.treemap_charts,
        },
    )


# New endpoint for building and visualising a predictive model
@app.post("/model", response_class=HTMLResponse)
async def build_model(
    request: Request,
    target_variable: str = Form(...),
    top_n: int = Form(5),
):
    """Build a predictive model for the selected target variable.

    The user selects a numeric column as the target and chooses how many
    top features to display.  A random forest model is trained and
    evaluated, and feature importances are shown.  Results are stored
    in the global state so that they persist across page reloads.
    """
    # Validate that a dataset has been loaded
    if state.dataset is None:
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": False,
                "preview_html": None,
                "summary_html": None,
                "corr_div": None,
                "narrative": None,
                "chat_history": [],
                "error": "Please upload a dataset before building a model.",
                "plotly_js": PLOTLY_JS,
                "numeric_columns": state.numeric_columns,
                "model_fig": state.model_fig,
                "model_metrics": state.model_metrics,
                "model_importance": state.model_importance,
                "hist_charts": state.hist_charts,
                "bar_charts": state.bar_charts,
                "time_series_charts": state.time_series_charts,
                "box_charts": state.box_charts,
                "scatter_matrix_charts": state.scatter_matrix_charts,
                "treemap_charts": state.treemap_charts,
            },
        )

    # Ensure the selected target variable exists and is numeric
    if state.numeric_columns is None or target_variable not in state.numeric_columns:
        # Provide an error message if invalid target selected
        error_msg = f"The target variable '{target_variable}' is not available or not numeric."
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": True,
                "preview_html": state.preview_html,
                "summary_html": state.summary_html,
                "corr_div": state.corr_div,
                "narrative": state.narrative,
                "chat_history": state.chat_history,
                "error": error_msg,
                "plotly_js": PLOTLY_JS,
                "numeric_columns": state.numeric_columns,
                "model_fig": state.model_fig,
                "model_metrics": state.model_metrics,
                "model_importance": state.model_importance,
                "hist_charts": state.hist_charts,
                "bar_charts": state.bar_charts,
                "time_series_charts": state.time_series_charts,
                "box_charts": state.box_charts,
                "scatter_matrix_charts": state.scatter_matrix_charts,
                "treemap_charts": state.treemap_charts,
            },
        )

    # Clamp top_n to a reasonable range (1-20)
    try:
        n_features = int(top_n)
        if n_features < 1:
            n_features = 1
        elif n_features > 20:
            n_features = 20
    except ValueError:
        n_features = 5

    # Build the model and get outputs
    try:
        fig_div, metrics_html, fi_table_html = build_predictive_model(
            state.dataset, target_variable, top_n=n_features
        )
        # Store results in global state
        state.model_fig = fig_div
        state.model_metrics = metrics_html
        state.model_importance = fi_table_html
    except Exception as exc:
        error_msg = f"Failed to build model: {exc}"
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": True,
                "preview_html": state.preview_html,
                "summary_html": state.summary_html,
                "corr_div": state.corr_div,
                "narrative": state.narrative,
                "chat_history": state.chat_history,
                "error": error_msg,
                "plotly_js": PLOTLY_JS,
                "numeric_columns": state.numeric_columns,
                "model_fig": state.model_fig,
                "model_metrics": state.model_metrics,
                "model_importance": state.model_importance,
                "hist_charts": state.hist_charts,
                "bar_charts": state.bar_charts,
                "time_series_charts": state.time_series_charts,
                "box_charts": state.box_charts,
                "scatter_matrix_charts": state.scatter_matrix_charts,
                "treemap_charts": state.treemap_charts,
            },
        )

    # Render the index template with updated context
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "dataset_loaded": True,
            "preview_html": state.preview_html,
            "summary_html": state.summary_html,
            "corr_div": state.corr_div,
            "narrative": state.narrative,
            "chat_history": state.chat_history,
            "plotly_js": PLOTLY_JS,
            "numeric_columns": state.numeric_columns,
            "model_fig": state.model_fig,
            "model_metrics": state.model_metrics,
            "model_importance": state.model_importance,
            "hist_charts": state.hist_charts,
            "bar_charts": state.bar_charts,
            "time_series_charts": state.time_series_charts,
            "box_charts": state.box_charts,
            "scatter_matrix_charts": state.scatter_matrix_charts,
            "treemap_charts": state.treemap_charts,
        },
    )