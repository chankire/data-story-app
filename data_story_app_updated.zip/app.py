"""
data_story_app/app.py
======================

This module implements a lightweight data‑analysis and storytelling web
application using FastAPI and Jinja2.  The application allows users to
upload a CSV file, automatically profiles the uploaded dataset and
displays exploratory data analysis (EDA) results such as descriptive
statistics, a correlation heatmap and a simple narrative summarising
interesting findings.  A rudimentary chat interface is also provided
allowing users to ask basic questions about the data (e.g. "mean of
revenue" or "plot age vs salary").  Responses to these queries are
generated using simple pattern matching against the uploaded dataset.

The resulting application can be launched locally via

    uvicorn app:app --reload

Once running, navigate to `http://localhost:8000/` in your web browser
to interact with the interface.  The server keeps the uploaded dataset
and chat state in memory for the lifetime of the process (no
persistence layer is implemented), so this example is suitable for
demonstration purposes but not for production deployment.

Prerequisites:
    - Python 3.8+
    - fastapi
    - uvicorn
    - jinja2
    - pandas
    - plotly (for interactive charts)

All of these packages are installed in the provided container, but if
you're running this code outside the container you should install
them via pip.  A minimal requirements.txt is provided in the
repository root for convenience.
"""

from fastapi import FastAPI, Request, UploadFile, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.offline as po
from io import StringIO
import re
import os

# Import get_plotlyjs to embed the script into the HTML so that
# charts work without an external network connection.  The returned
# string contains a minified copy of the Plotly JavaScript library.
from plotly.offline import get_plotlyjs


# Instantiate the FastAPI app
app = FastAPI(title="Data Story App")

# Set up Jinja2 templates; templates live in the `templates` directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

# Mount a static directory for serving assets (optional)
static_dir = os.path.join(BASE_DIR, "static")
if not os.path.exists(static_dir):
    os.makedirs(static_dir, exist_ok=True)
app.mount("/static", StaticFiles(directory=static_dir), name="static")

# In‑memory state for the currently loaded dataset and chat history.
# In a production system you'd implement proper per‑session storage or a
# database instead of these module‑level variables.
class AppState:
    dataset: pd.DataFrame | None = None
    preview_html: str | None = None
    summary_html: str | None = None
    corr_div: str | None = None
    narrative: str | None = None
    chat_history: list[dict] = []


state = AppState()

# Embed plotly.js into the template to avoid external network calls.
PLOTLY_JS = get_plotlyjs()


def load_dataset(file: UploadFile) -> pd.DataFrame:
    """Load a dataset from an uploaded file.

    Currently supports CSV files.  XLSX files could be added easily by
    checking file.content_type and using pandas.read_excel.

    Parameters
    ----------
    file : UploadFile
        The uploaded file object.

    Returns
    -------
    pd.DataFrame
        The loaded data.
    """
    # Read the file contents into a pandas DataFrame
    contents = file.file.read().decode("utf-8", errors="ignore")
    # Use StringIO to simulate a file handle for pandas
    data = pd.read_csv(StringIO(contents))
    return data


def generate_preview(df: pd.DataFrame, max_rows: int = 5) -> str:
    """Generate an HTML table preview of the first few rows."""
    preview_df = df.head(max_rows).copy()
    return preview_df.to_html(classes="dataframe table table-striped table-bordered", index=False, border=0)


def generate_summary(df: pd.DataFrame) -> str:
    """Compute descriptive statistics for numeric columns and render as HTML."""
    # Only include numeric columns for summary statistics
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.empty:
        return "<p>No numeric columns available for summary statistics.</p>"
    desc = numeric_df.describe().transpose()
    desc.reset_index(inplace=True)
    desc.rename(columns={"index": "column"}, inplace=True)
    # Round statistics for readability
    desc = desc.round(3)
    return desc.to_html(classes="dataframe table table-striped table-bordered", index=False, border=0)


def generate_correlation_heatmap(df: pd.DataFrame) -> str:
    """Create a Plotly correlation heatmap and return HTML div."""
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.shape[1] < 2:
        return ""
    corr_matrix = numeric_df.corr()
    fig = px.imshow(
        corr_matrix,
        text_auto=False,
        aspect="auto",
        labels=dict(color="Correlation"),
        x=corr_matrix.columns,
        y=corr_matrix.index,
        title="Correlation Heatmap"
    )
    fig.update_layout(height=500)
    # Convert Plotly figure to an HTML div string.  We exclude the
    # Plotly.js library here to avoid multiple inclusions on the page; the
    # script is included once in the base template.
    heatmap_div = po.plot(fig, include_plotlyjs=False, output_type='div')
    return heatmap_div


def generate_narrative(df: pd.DataFrame) -> str:
    """Generate a simple textual narrative summarising the dataset.

    This heuristic narrative calls out interesting aspects of the data:
    the number of rows/columns, the column with the most missing values,
    columns with the largest mean values, and highly correlated pairs.

    Returns an HTML string.
    """
    n_rows, n_cols = df.shape
    numeric_df = df.select_dtypes(include=[np.number])
    narrative_parts = []

    # Data size
    narrative_parts.append(
        f"<p>Your dataset contains <strong>{n_rows}</strong> rows and <strong>{n_cols}</strong> columns.</p>"
    )

    # Missing values
    missing_counts = df.isna().sum()
    if missing_counts.sum() > 0:
        max_missing_col = missing_counts.idxmax()
        max_missing_count = missing_counts[max_missing_col]
        narrative_parts.append(
            f"<p>The column with the most missing values is <strong>{max_missing_col}</strong> "
            f"with <strong>{int(max_missing_count)}</strong> missing entries.</p>"
        )
    else:
        narrative_parts.append("<p>There are no missing values in this dataset.</p>")

    # Largest mean values
    if not numeric_df.empty:
        means = numeric_df.mean().sort_values(ascending=False)
        top_means = means.head(min(3, len(means)))
        top_mean_phrases = [f"<strong>{col}</strong> (mean={val:.2f})" for col, val in top_means.items()]
        narrative_parts.append(
            "<p>The columns with the highest mean values are: " + ", ".join(top_mean_phrases) + ".</p>"
        )

        # Highly correlated pairs
        corr_matrix = numeric_df.corr().abs()
        # Select upper triangle of correlation matrix to avoid duplicates and self correlations
        upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        # Identify pairs above threshold
        threshold = 0.8
        high_corr = [(col1, col2, val) for col1 in upper_tri.columns for col2, val in upper_tri[col1].dropna().items() if val >= threshold]
        if high_corr:
            phrases = [f"<strong>{c1}</strong> and <strong>{c2}</strong> (corr={val:.2f})" for c1, c2, val in high_corr]
            narrative_parts.append(
                "<p>Highly correlated column pairs include: " + "; ".join(phrases) + ".</p>"
            )

    return "\n".join(narrative_parts)


def handle_query(df: pd.DataFrame, query: str) -> tuple[str, str | None]:
    """Interpret a simple natural language query and return a response.

    The function looks for patterns such as 'mean of column', 'median of column',
    'sum of column', 'max of column', 'min of column', 'plot col1 vs col2',
    'plot distribution of column', 'correlation between col1 and col2', and
    'count' (number of rows).

    It returns a tuple consisting of the textual answer and an optional
    Plotly figure represented as an HTML div string.  If the query could
    not be parsed, a message is returned along with None.

    Parameters
    ----------
    df : pd.DataFrame
        The dataset to query.
    query : str
        The user's freeform question.

    Returns
    -------
    Tuple[str, Optional[str]]
        A textual answer and optionally an HTML div for a chart.
    """
    # Lowercase the query for easier matching
    q = query.strip().lower()

    # Handle count
    if re.fullmatch(r"(number of rows|count)", q):
        return (f"The dataset contains {df.shape[0]} rows.", None)

    # Mean
    m = re.match(r"mean of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The mean of {col} is {df[col].mean():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Median
    m = re.match(r"median of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The median of {col} is {df[col].median():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Sum
    m = re.match(r"sum of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The sum of {col} is {df[col].sum():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Max
    m = re.match(r"max(?:imum)? of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The maximum of {col} is {df[col].max():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Min
    m = re.match(r"min(?:imum)? of ([\w\s]+)", q)
    if m:
        col = m.group(1).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            return (f"The minimum of {col} is {df[col].min():.3f}.", None)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Correlation between columns
    m = re.match(r"corr(?:elation)? between ([\w\s]+) and ([\w\s]+)", q)
    if m:
        col1 = m.group(1).strip()
        col2 = m.group(2).strip()
        if (col1 in df.columns and col2 in df.columns and 
                pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2])):
            corr_val = df[col1].corr(df[col2])
            return (f"The correlation between {col1} and {col2} is {corr_val:.3f}.", None)
        else:
            return (f"One or both columns not found or not numeric.", None)

    # Histogram / distribution
    m = re.match(r"(plot|show) (?:the )?(?:distribution|histogram) of ([\w\s]+)", q)
    if m:
        col = m.group(2).strip()
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            fig = px.histogram(df, x=col, nbins=20, title=f"Distribution of {col}")
            fig.update_layout(height=400)
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            return (f"Here is the distribution of {col}.", fig_div)
        else:
            return (f"Column '{col}' not found or is not numeric.", None)

    # Scatter plot
    m = re.match(r"(plot|show) ([\w\s]+) vs ([\w\s]+)", q)
    if m:
        col1 = m.group(2).strip()
        col2 = m.group(3).strip()
        if (col1 in df.columns and col2 in df.columns and 
                pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2])):
            fig = px.scatter(df, x=col1, y=col2, title=f"{col1} vs {col2}")
            fig.update_layout(height=400)
            fig_div = po.plot(fig, include_plotlyjs=False, output_type='div')
            return (f"Here is the scatter plot of {col1} vs {col2}.", fig_div)
        else:
            return (f"One or both columns not found or not numeric.", None)

    # Fallback
    return ("I'm sorry, I didn't understand your question. "
            "Try queries like 'mean of revenue', 'plot age vs salary', "
            "'sum of sales' or 'correlation between price and quantity'.", None)


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Render the main page.

    The page displays a file upload form.  If a dataset is loaded in the
    application state, it additionally shows the preview table,
    summary statistics, a correlation heatmap, narrative text and the
    chat interface with existing history.
    """
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "dataset_loaded": state.dataset is not None,
            "preview_html": state.preview_html,
            "summary_html": state.summary_html,
            "corr_div": state.corr_div,
            "narrative": state.narrative,
            "chat_history": state.chat_history,
            "plotly_js": PLOTLY_JS,
        },
    )


@app.post("/upload", response_class=RedirectResponse)
async def upload_dataset(request: Request, file: UploadFile):
    """Handle file upload and compute analysis results.

    After loading the dataset, the function generates all analysis
    artefacts (preview table, summary stats, correlation heatmap,
    narrative) and resets the chat history.  The client is then
    redirected back to the main page to display the results.
    """
    try:
        df = load_dataset(file)
    except Exception as exc:
        # On failure, redirect back without loading dataset
        print(f"Failed to load dataset: {exc}")
        return RedirectResponse("/", status_code=303)

    # Update the global state
    state.dataset = df
    state.preview_html = generate_preview(df)
    state.summary_html = generate_summary(df)
    state.corr_div = generate_correlation_heatmap(df)
    state.narrative = generate_narrative(df)
    state.chat_history = []

    # Redirect back to the index to show results
    return RedirectResponse("/", status_code=303)


@app.post("/query", response_class=HTMLResponse)
async def process_query(request: Request, user_query: str = Form(...)):
    """Process a user's chat query and return updated page.

    The user's query is answered using a simple parser in `handle_query`.
    The resulting answer is appended to the chat history.  The page is
    re‑rendered with the updated chat history and, if a chart is
    produced, the chart is included at the end of the chat.
    """
    if state.dataset is None:
        # No dataset loaded yet; show a message
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "dataset_loaded": False,
                "preview_html": None,
                "summary_html": None,
                "corr_div": None,
                "narrative": None,
                "chat_history": [],
                "error": "Please upload a dataset before asking questions.",
                "plotly_js": PLOTLY_JS,
            },
        )

    # Generate answer and optional chart
    answer_text, fig_div = handle_query(state.dataset, user_query)
    entry = {"user": user_query, "response": answer_text, "figure": fig_div}
    state.chat_history.append(entry)

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "dataset_loaded": True,
            "preview_html": state.preview_html,
            "summary_html": state.summary_html,
            "corr_div": state.corr_div,
            "narrative": state.narrative,
            "chat_history": state.chat_history,
            "plotly_js": PLOTLY_JS,
        },
    )